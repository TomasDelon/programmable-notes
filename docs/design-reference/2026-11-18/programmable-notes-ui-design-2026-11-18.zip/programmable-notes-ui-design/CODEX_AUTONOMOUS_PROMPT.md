# Autonomous development request for Codex Cloud

You are the principal engineer maintaining **TomasDelon/programmable-notes**. Continue the existing Codex Cloud work autonomously on its current feature branch and draft PR. The goal is a **secure, durable, technically reliable Linux MDX editor**, not a styling sprint.

The attached `programmable-notes-ui-design-2026-11-18.zip` is a **temporary visual reference**. The owner is still refining that design and will send updated guidance later. **Do not spend this session redesigning the app or blindly replacing its UI with the static demo.** Preserve the current working interface and focus on the engineering backlog below. Once explicit updated design instructions arrive, adapt the existing production components to the approved visual language while preserving security and data integrity.

## Ground truth first

1. Inspect the actual repository, branches, current `feat/mdx-react-engine` head, draft PR #1, working tree, CI results, `AGENTS.md`, README, tests, `docs/IMPLEMENTATION_STATUS.md`, and relevant security evidence. The last status relayed by the owner mentioned a packaged Ubuntu/WebKitGTK acceptance pass, a manual recovery slot, and feature head `4e9ed86`; **those are historical hints, not current verified state**. Never overwrite newer work or infer a task is finished from an existing branch.
2. Record a concise baseline in `docs/AGENT_PROGRESS.md`: exact revision, PR link, functionality present, failing or skipped checks, important open risks, current milestone, next executable action. Update this file as work proceeds so a future Codex session can resume without asking the owner to restate context.
3. Reproduce the relevant baseline tests in the available environment. Distinguish local executions, hosted GitHub checks, packaged-native runs, and untested platforms. If a particular stack is unavailable, do not fabricate a pass.

## Priorities, in order

### P0. Recovery durability and bounded versioned snapshots

Replace the single manual private recovery slot with a carefully designed, **bounded and versioned** snapshot store under app-private storage. Establish an explicit schema/version, identity and revision semantics, integrity check, retention policy, size/count limits, deterministic conflict rules, and a migration path from the existing manual slot. Favor simple auditable mechanisms over clever storage frameworks.

Protect the invariants already established: a recovery operation must never silently overwrite an existing winning snapshot, a restored document opens as a **separate dirty/unsaved buffer** without an implicit grant to the original file, invalid UTF-8 or corrupted records are rejected safely, and the untrusted React preview can neither read nor mutate private recovery state.

Write tests for interrupted writes at every meaningful stage, partial/corrupted records, full storage / ENOSPC, process restart, duplicate attempts, concurrent writers, retention boundaries, migration, and rollback or safe failure. Use temp directories and synthetic files. Ensure expected failures never destroy a valid earlier snapshot. Decide explicitly when fsync, atomic rename, directory sync, and locking are available and implement platform-appropriate guarantees rather than claiming generic atomicity.

### P1. Native draft autosave, without overwriting the source file

After P0 is stable, implement bounded, debounced recovery snapshots for dirty native documents, with backpressure and clear error semantics. **Autosave must mean autosave to private recovery storage**, not silent mutation of the original MDX file. Explicit Save/Save As and native file grants remain distinct. Verify edits, restart, recovery discovery, restore-as-unsaved, save to an explicitly chosen destination, and reopening. Avoid unbounded snapshots and uncontrolled background writes.

### P2. Source fidelity and editing correctness

Keep the byte-preserving source model as the authority. Extend in-place editing only where original MDX can be transformed without unintended formatting changes. Cover existing plain paragraphs, ATX/Setext headings, simple list items, undo/redo, Enter to apply, Escape to cancel, dirty-close and external modifications. Handle unsupported or ambiguous constructs through an honest source-mode fallback instead of corrupting MDX. Add property-based or fixture-driven regression tests for Unicode, CRLF/LF, whitespace, nested syntax, MDX/JSX, front matter, code fences, and round-trip byte fidelity where no edit occurs.

Inspect the watcher/runtime generation sequence. Unit tests and watch mode must generate `.cache/runtime.js` before Vitest; CI must generate it explicitly; browser build must generate it through the build. Do not commit generated runtime or depend on stale local artifacts. Verify from a clean tracked-tree copy using `npm ci` and appropriate commands.

### P3. Isolation and file permissions

Audit every native command exposed to the WebView and React preview. Keep preview rendering isolated and least-privileged: no filesystem, recovery, or shell access through imported MDX/JSX; no unsafe code execution in the privileged context; strong CSP/sandbox boundaries and tests proving denials. Preserve revocable and narrow native file grants, external-write conflict detection, and unsaved buffers. Add adverse tests for path traversal, symlink changes, invalid encodings, permission revocation, unexpected process failures, and concurrent native document writes. Treat these as security boundaries, not merely UI flows.

### P4. Packaged Linux end-to-end reliability

Build and run the installed Debian/Tauri package in a real Ubuntu + WebKitGTK environment when available. Test inline edit, Enter/Escape, undo/redo, exact MDX bytes, Save, close/reopen, dirty-close dialog, snapshot recovery through an actual process restart, corrupted/full storage, and blocked preview-native commands. Preserve previous evidence under versioned `docs/security-evidence/` directories, with package hashes, environment versions, reproduction steps, and a clear pass/fail/blocked classification. Explicitly separate desktop compatibility gaps (Mesa/GPU, Wayland, WebDriver Escape reliability) from source-data durability gaps.

### P5. Continue the strongest remaining engineering issue

Once earlier priorities pass, choose the next objectively useful technical milestone from `docs/IMPLEMENTATION_STATUS.md` and the observed tests. Prefer reliability, performance under large documents, incremental parsing, external file changes, multi-document correctness, keyboard accessibility, error recovery, and CI determinism over feature proliferation. Build a small vertical slice, test it, commit it, and continue. Do not add speculative integrations, plugins, cloud sync, telemetry, or unrelated frameworks just to fill time.

## Working method and autonomy

- Work in small, independently testable vertical slices on the existing feature branch. Do not force-push, merge into `main`, rewrite shared history, or modify unrelated repositories. Respect existing worktrees, user changes, and branch protections.
- Inspect before every substantial change; use tests first when practical. Preserve behavior and security invariants. Run relevant unit, browser, native, and package checks where feasible. Do not claim tests passed unless actually run on the stated revision.
- For each successful slice: commit with a descriptive message, push to the feature branch, update the existing **draft PR**, and record what changed, test evidence, unresolved risks, and the next slice in `docs/AGENT_PROGRESS.md` (or a PR progress comment). Keep CI monitored after pushes; fix regressions before expanding scope.
- Prefer straightforward dependency-light designs. Any new dependency, capability, native permission, filesystem write path, or migration requires an explicit reason and a regression test. Never use private user documents as fixtures. Never upload personal files, secrets, recovery data, or machine-specific state to GitHub.
- Make ordinary engineering decisions independently. If multiple safe designs work, pick the simplest reversible option, document the trade-off, and proceed. Do not interrupt the owner for preferences about naming, minor UX, test structure, code style, or implementation detail.
- **Stop and ask only** if progress truly requires missing credentials/authorization, a destructive action outside this scope, an irreversible migration, a security boundary expansion, a protected merge, or a product choice with materially different consequences. Treat explicit access denials as stop conditions; do not work around them.
- Continue tackling the prioritized backlog through the whole available execution window. After each milestone, pick the next verified task instead of waiting for a new prompt. Maintain compact, durable checkpoints for context resets, worker restarts, or future sessions. You cannot promise uninterrupted execution for days if the Codex environment stops; make every session resumable from Git and `docs/AGENT_PROGRESS.md`.

## Quality gates and reporting

Do not mark the implementation complete just because a branch or PR exists. A milestone is complete only when code and tests are present, relevant checks pass, failure modes have been exercised, and remaining gaps are explicitly recorded. Keep draft status until a separate owner-approved release/merge decision.

When reporting a checkpoint, provide: exact commit and draft PR URLs; changed files or areas; local test commands and counts/results; GitHub Actions state for that exact head; packaged-native evidence if performed; blockers with reproducible steps; and the recommended next technical action. Distinguish verified GitHub evidence from unobservable work inside this Codex Cloud session.

Begin **now** with the live repository audit and P0 snapshot design/tests. Do not pause after producing a plan: implement, verify, commit, push, update the draft PR, and continue with the next bounded task.
