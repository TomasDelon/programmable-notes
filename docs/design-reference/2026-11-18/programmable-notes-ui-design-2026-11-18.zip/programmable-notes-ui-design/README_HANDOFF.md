# Programmable Notes UI, visual handoff

Snapshot date: 2026-11-18 (Europe/Paris)

This is a **design reference**, not the implementation of Programmable Notes. The prototype was developed separately in ChatGPT Sites. It contains runnable static HTML, CSS, JavaScript, sample documents, and browser-local interactions. It does **not** contain the Tauri/WebKitGTK desktop backend, a secure MDX compiler, native file grants, or durable recovery.

## Open the reference

1. Extract the ZIP.
2. From the extracted folder, run `python3 -m http.server 8080`.
3. Visit `http://localhost:8080/` and explore the light/dark appearance, folder navigation, document views, code toolbars, toggles, dialogs, and settings.
4. To rebuild the generated page after changing source, run `node build.mjs`. Then serve `dist/` or refresh the root `index.html` if copying a fresh build there.
5. Run `node --test minimal-layout.test.mjs` for the design contract tests.

Live reference (private, accessible to the owner):
https://tomas-programmable-notes-ui.tomasdelon.chatgpt.site/

Prototype source revision at handoff: `a952e01445c44fbd68a4c36ebf612cd190e3edb5` (the **Sites prototype repository**, not the main app repository).

## Files

- `index.html`: generated runnable browser demo.
- `assets/XCharter-Math.otf`: bundled mathematical font.
- `shell.html`, `styles.css`, `app.js`, `pages-extra.js`: editable visual sources.
- `build.mjs`: dependency-free demo builder.
- `minimal-layout.test.mjs`: UI contract checks.
- `QA-CHECKLIST.md`: manual design review checklist.
- `FONT_NOTICES.md`: font attribution and source links.
- `CODEX_AUTONOMOUS_PROMPT.md`: suggested next technical development request.

## Non-negotiable distinction

Do not copy the demo's browser-local storage, sample-page data model, or script execution design into production as if they were secure or durable. The real app already has source-preserving editing, a React preview isolation boundary, native filesystem grants, and recovery mechanisms. Integrate approved visual features into those **existing** components only after the owner sends final UI guidance. Until then, prioritize technical reliability.

## Visual intent, subject to review

- Minimal document canvas, no top or bottom utility bars.
- Two small transparent floating controls in the upper corners reveal side panels.
- Left panel: folders, documents, search, page creation, and account at the bottom.
- Thin centered top-edge handle morphs into a Preview / Source capsule. No Split option.
- Code controls appear only on hover or keyboard focus, as a compact floating capsule.
- Borderless inline disclosures; callouts share body typography.
- Minimal translucent scrollbar affordance, unobtrusive counts in lower-right when appropriate.
- Light and dark appearance.
- Fonts **as captured**: JetBrains Mono text/code, XCharter Math formulas. The owner is still considering a serif reading font such as Source Serif 4. Do not interpret the captured font selection as final approval.

The prototype is a reference for future UI integration, not a demand to stop the technical roadmap now.
