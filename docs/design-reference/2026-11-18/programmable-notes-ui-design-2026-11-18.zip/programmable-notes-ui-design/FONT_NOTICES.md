# Font notices

- **JetBrains Mono** by JetBrains, licensed under SIL Open Font License 1.1. Loaded as a webfont in the visual prototype. [Source and license](https://github.com/JetBrains/JetBrainsMono).
- **XCharter Math** by Daniel Flipo, licensed under SIL Open Font License 1.1. An unmodified copy of the mathematical OpenType font is bundled in `assets/XCharter-Math.otf` for reliable MathML presentation. [Official CTAN package](https://ctan.org/pkg/xcharter-math) and [license](https://openfontlicense.org/open-font-license-official-text/).

The formulas shown in this visual prototype are hand-authored MathML paired with example LaTeX source; the prototype does not implement a general-purpose TeX parser.
