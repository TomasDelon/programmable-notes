'use strict';
(() => {
  const paths = {
    search:'<circle cx="10.8" cy="10.8" r="6.3"/><path d="m16 16 4.2 4.2"/>',
    home:'<path d="m3 10 9-7 9 7v10H3V10Z"/><path d="M9 20v-7h6v7"/>',
    grid:'<rect x="3" y="3" width="7" height="7" rx="1.3"/><rect x="14" y="3" width="7" height="7" rx="1.3"/><rect x="3" y="14" width="7" height="7" rx="1.3"/><rect x="14" y="14" width="7" height="7" rx="1.3"/>',
    file:'<path d="M13 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10Z"/><path d="M13 3v7h7M8 14h8M8 17h5"/>',
    folder:'<path d="M3 6a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>',
    chevrons:'<path d="m8 9 4-4 4 4m-8 6 4 4 4-4"/>',
    chevron:'<path d="m9 5 7 7-7 7"/>',
    down:'<path d="m6 9 6 6 6-6"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    minus:'<path d="M5 12h14"/>',
    settings:'<path d="m9.5 3-.7 2.4-2 .9-2.2-.5L2.5 9.5 4 11.3v2.3l-1.5 1.9 2.1 3.7 2.2-.5 2 .9.7 2.4h5l.7-2.4 2-.9 2.2.5 2.1-3.7-1.5-1.9v-2.3l1.5-1.8-2.1-3.7-2.2.5-2-.9-.7-2.4h-5Z"/><circle cx="12" cy="12.5" r="3"/>',
    moon:'<path d="M20.8 13.2A8.7 8.7 0 0 1 10.8 3a8.8 8.8 0 1 0 10 10.2Z"/>',
    sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    monitor:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>',
    sidebar:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
    panel:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M15 4v16"/>',
    columns:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M12 4v16"/>',
    eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    star:'<path d="m12 3 2.8 5.7 6.3.9-4.5 4.4 1 6.2-5.6-3-5.6 3 1-6.2L3 9.6l6.2-.9Z"/>',
    more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    code:'<path d="m7 6-5 6 5 6m10-12 5 6-5 6m-3-15-4 18"/>',
    braces:'<path d="M8 3H6a2 2 0 0 0-2 2v4l-2 3 2 3v4a2 2 0 0 0 2 2h2m8-18h2a2 2 0 0 1 2 2v4l2 3-2 3v4a2 2 0 0 1-2 2h-2"/>',
    chart:'<path d="M4 3v17h17M7 15l5-6 4 3 4-7"/>',
    layers:'<path d="m12 3 10 5-10 5L2 8Zm-9 9 9 5 9-5m-18 5 9 5 9-5"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 11h18M7 15h2m4 0h2m-8 3h2"/>',
    leaf:'<path d="M20 3s-10-1-14 4c-4 5 0 12 5 11 7-1 9-8 9-15Z"/><path d="M4 21 15 9"/>',
    book:'<path d="M12 5C8 2 3 3 3 3v16s5-1 9 2c4-3 9-2 9-2V3s-5-1-9 2Zm0 0v16"/>',
    'hard-drive':'<path d="m3 14 3-9h12l3 9"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 17h.1m3.9 0h.1"/>',
    command:'<path d="M9 7V5a2 2 0 1 0-2 2h10a2 2 0 1 0-2-2v14a2 2 0 1 0 2-2H7a2 2 0 1 0 2 2Z"/>',
    close:'<path d="m6 6 12 12M6 18 18 6"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',
    return:'<path d="M20 5v7H4m6-6-6 6 6 6"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
    lightbulb:'<path d="M8 16c0-3-3-3-3-7a7 7 0 1 1 14 0c0 4-3 4-3 7M8 18h8m-7 3h6"/>',
    copy:'<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M15 8V3H3v13h5"/>',
    download:'<path d="M12 3v12m-5-5 5 5 5-5M3 16v5h18v-5"/>',
    edit:'<path d="m14 5 5 5M4 20l5-1L21 7l-5-5L4 14v6Z"/>',
    trash:'<path d="M3 6h18M8 6V3h8v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
    focus:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m8 0h5v-5"/>',
    history:'<path d="M3 10a9 9 0 1 1 1 7M3 4v6h6m3-3v6l4 2"/>',
    lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
    link:'<path d="m10 13 4-4m-6 6-2 2a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0m4 2 2-2a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0" transform="translate(1 0)"/>',
    github:'<path d="M9 19c-4 1-4-2-6-2m12 5v-4c0-1-.2-1.8-1-2 3-.4 6-1.5 6-6 0-1.4-.5-2.5-1.5-3.5.2-1 .2-2.1-.1-3.1 0 0-1.3-.4-3.9 1.5a13 13 0 0 0-7 0C4.9 3 3.6 3.4 3.6 3.4c-.3 1-.3 2.1-.1 3.1C2.5 7.5 2 8.6 2 10c0 4.5 3 5.6 6 6-.8.2-1 1-1 2v4"/>',
    cloud:'<path d="M6 18a5 5 0 1 1 .4-10 6 6 0 0 1 11.4-1.2A5.5 5.5 0 1 1 18 18Z"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    sliders:'<path d="M4 7h7m4 0h5M4 17h3m4 0h9"/><circle cx="13" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    sparkle:'<path d="m12 3 2.3 6.7L21 12l-6.7 2.3L12 21l-2.3-6.7L3 12l6.7-2.3ZM20 2v4m-2-2h4"/>',
    typography:'<path d="m3 20 7-17 7 17M6 13h8m3 3h5m-2-5v10"/>',
  };
  const icon = (name, cls = '') => `<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.file}</svg>`;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
  const keyName = isMac ? '⌘' : 'Ctrl';
  const STORAGE_KEY = 'programmable-notes-style-v1';
  const folders = ['Ensimag','Projects','Personal'];
  const seeded = [{
    id:'regression',title:'Linear regression',icon:'chart',folder:'Ensimag',tag:'PS1 · Statistics',
    description:'From a cloud of observations to a model we can reason about.',updated:'Sample note',
    outline:[{id:'overview',title:'The idea, in one line'},{id:'least-squares',title:'Finding the best fit'},{id:'read-model',title:'Reading the model'},{id:'further-reading',title:'Keep exploring'}],
    source:"import { RegressionPlot } from './examples/RegressionPlot'\n\n# Linear regression\n\nFrom a cloud of observations to a model we can reason about.\n\n## The idea, in one line\n\nLinear regression describes how a response changes with an explanatory variable. We fit a line to the data, then ask how much of the variation that line can explain.\n\n$$y_i = \\beta_0 + \\beta_1 x_i + \\varepsilon_i$$\n\n> The model is linear in its coefficients, not necessarily in the original variables.\n\n## Finding the best fit\n\n<RegressionPlot sample=\"illustrative\" />\n\nLeast squares chooses the coefficients that minimize the sum of squared residuals. The slope can be written as:\n\n$$\\hat{\\beta}_1 = \\frac{\\sum_{i=1}^{n}(x_i-\\bar{x})(y_i-\\bar{y})}{\\sum_{i=1}^{n}(x_i-\\bar{x})^2}$$\n\n## Reading the model\n\nThe coefficient of determination is \\(R^2 = 1 - \\frac{\\mathrm{SSE}}{\\mathrm{SST}}\\).\n\n```r\nmodel <- lm(log10(co2) ~ log10(gni), data = sample)\nsummary(model)\n```\n\n## Keep exploring\n\nSeparate a fitted relationship from a causal explanation.\n",
    body:`<h2 id="overview">The idea, in one line</h2><p>Linear regression describes how a response changes with an explanatory variable. We fit a line to the data, then ask <strong>how much of the variation that line can explain.</strong></p>
    <div class="equation" data-latex="y_i = \\beta_0 + \\beta_1 x_i + \\varepsilon_i" aria-label="y sub i equals beta zero plus beta one x sub i plus epsilon sub i"><math display="block" xmlns="http://www.w3.org/1998/Math/MathML"><mrow><msub><mi>y</mi><mi>i</mi></msub><mo>=</mo><msub><mi>β</mi><mn>0</mn></msub><mo>+</mo><msub><mi>β</mi><mn>1</mn></msub><msub><mi>x</mi><mi>i</mi></msub><mo>+</mo><msub><mi>ε</mi><mi>i</mi></msub></mrow></math></div>
    <div class="note-callout">${icon('lightbulb')}<div><span class="callout-label">A useful distinction</span><p>The model is linear in its <strong>coefficients</strong>, not necessarily in the original variables. A log transformation still gives us a linear model.</p></div></div>
    <h2 id="least-squares">Finding the best fit</h2><p>Every point tells a slightly different story. Least squares finds the line that keeps their combined, squared distance as small as possible.</p>
    <div class="chart-card"><div class="chart-header"><strong>A trend within the noise</strong><div class="legend"><span><i class="legend-dot"></i>Observation</span><span><i class="legend-line"></i>Fitted line</span></div></div>
    <svg class="plot" viewBox="0 0 640 232" role="img" aria-label="Illustrative scatter plot with a positive linear trend. This is sample data, not an analysis result."><path class="gridline" d="M49 42H611M49 89H611M49 136H611M49 183H611"/><text x="26" y="46">8</text><text x="26" y="93">6</text><text x="26" y="140">4</text><text x="26" y="187">2</text><text x="63" y="210">0</text><text x="194" y="210">2</text><text x="326" y="210">4</text><text x="458" y="210">6</text><text x="590" y="210">8</text><text x="303" y="229">Explanatory variable</text>
    <path id="regression-line" class="fit-line" d="M64 178 590 48"/><circle cx="78" cy="181" r="4.2"/><circle cx="99" cy="162" r="4"/><circle cx="125" cy="183" r="4.3"/><circle cx="147" cy="146" r="4"/><circle cx="172" cy="162" r="4"/><circle cx="193" cy="139" r="4.5"/><circle cx="223" cy="142" r="4"/><circle cx="245" cy="117" r="4"/><circle cx="267" cy="145" r="4"/><circle cx="290" cy="108" r="4.5"/><circle cx="316" cy="129" r="4"/><circle cx="340" cy="94" r="4"/><circle cx="361" cy="116" r="4.5"/><circle cx="385" cy="87" r="4"/><circle cx="411" cy="105" r="4"/><circle cx="434" cy="72" r="4.5"/><circle cx="455" cy="93" r="4"/><circle cx="477" cy="55" r="4"/><circle cx="501" cy="76" r="4.5"/><circle cx="527" cy="42" r="4"/><circle cx="549" cy="62" r="4"/><circle cx="578" cy="38" r="4.5"/></svg>
    <div id="fit-controls" class="fit-controls" hidden><label for="slope-slider">Explore the slope</label><input type="range" id="slope-slider" min="0" max="2" value="1" step="0.05"><output id="slope-output" for="slope-slider">1.00</output><button class="icon-button" data-action="reset-slope" title="Reset slope" aria-label="Reset slope">${icon('history')}</button></div>
    <div class="chart-caption"><span>${icon('code')}Interactive example · illustrative data</span><button data-action="explore-fit" aria-expanded="false">Explore the fit ${icon('arrow')}</button></div></div>
    <p>For paired observations, the least-squares slope can be expressed as:</p>
    <div class="equation" data-latex="\\hat{\\beta}_1 = \\frac{\\sum_{i=1}^{n}(x_i-\\bar{x})(y_i-\\bar{y})}{\\sum_{i=1}^{n}(x_i-\\bar{x})^2}" aria-label="Least-squares slope formula"><math display="block" xmlns="http://www.w3.org/1998/Math/MathML"><mrow><msub><mover><mi>β</mi><mo>^</mo></mover><mn>1</mn></msub><mo>=</mo><mfrac><mrow><munderover><mo>∑</mo><mrow><mi>i</mi><mo>=</mo><mn>1</mn></mrow><mi>n</mi></munderover><mo>(</mo><msub><mi>x</mi><mi>i</mi></msub><mo>−</mo><mover><mi>x</mi><mo>¯</mo></mover><mo>)</mo><mo>(</mo><msub><mi>y</mi><mi>i</mi></msub><mo>−</mo><mover><mi>y</mi><mo>¯</mo></mover><mo>)</mo></mrow><mrow><munderover><mo>∑</mo><mrow><mi>i</mi><mo>=</mo><mn>1</mn></mrow><mi>n</mi></munderover><msup><mrow><mo>(</mo><msub><mi>x</mi><mi>i</mi></msub><mo>−</mo><mover><mi>x</mi><mo>¯</mo></mover><mo>)</mo></mrow><mn>2</mn></msup></mrow></mfrac></mrow></math></div>
    <h2 id="read-model">Reading the model</h2><p>The slope measures the expected change in the response for a one-unit change in the predictor. The residual is what the model leaves unexplained. The coefficient of determination <math class="inline-math" data-latex="R^2 = 1 - \\frac{\\mathrm{SSE}}{\\mathrm{SST}}" xmlns="http://www.w3.org/1998/Math/MathML"><mrow><msup><mi>R</mi><mn>2</mn></msup><mo>=</mo><mn>1</mn><mo>−</mo><mfrac><mi mathvariant="normal">SSE</mi><mi mathvariant="normal">SST</mi></mfrac></mrow></math> summarizes the fraction explained.</p>
    <div class="code-block"><div class="code-label"><span>R · a minimal example</span><button data-action="copy-code" aria-label="Copy R example">${icon('copy')} Copy</button></div><pre><code>model &lt;- <span class="syntax-keyword">lm</span>(log10(co2) ~ log10(gni), data = sample)\n<span class="syntax-keyword">summary</span>(model)</code></pre></div>
    <details><summary>What does R² actually tell us?</summary><div><p>For an ordinary least-squares model with an intercept, R² is the fraction of the observed response variation explained by the fitted model. It is not a measure of causation.</p></div></details>
    <h2 id="further-reading">Keep exploring</h2><p>Look at the residuals, question the assumptions, and separate a fitted relationship from a causal explanation. Connect this note with <button class="inline-link" data-action="navigate" data-page="algorithms">Algorithms &amp; complexity</button> when thinking about computation.</p>`
  }, ...window.EXTRA_PAGES, {
    id:'playground',title:'React playground',icon:'code',folder:'Projects',tag:'MDX · Interactive',description:'A document can be more than words on a page.',updated:'Sample note',
    outline:[{id:'small-experiment',title:'A small experiment'},{id:'source-example',title:'The source behind it'},{id:'prototype-boundary',title:'About this prototype'}],
    source:"import { useState } from 'react'\n\nexport function Counter() {\n  const [count, setCount] = useState(0)\n  return <button onClick={() => setCount(count + 1)}>{count}</button>\n}\n\n# React playground\n\n## A small experiment\n\n<Counter />\n\nMarkdown for the explanation. React for the interaction.\n",
    body:`<h2 id="small-experiment">A small experiment</h2><p>Markdown for the explanation. React for the interaction. The production editor lets these ideas live in the same source document.</p><div class="demo-counter"><button class="button" data-action="counter-down" aria-label="Decrease counter">${icon('minus')}</button><output id="demo-count" aria-live="polite">0</output><button class="button" data-action="counter-up" aria-label="Increase counter">${icon('plus')}</button><span>Frontend example</span></div><h2 id="source-example">The source behind it</h2><div class="code-block"><div class="code-label"><span>JSX</span><button data-action="copy-code">${icon('copy')} Copy</button></div><pre><code><span class="syntax-keyword">const</span> [count, setCount] = useState(0)\n\n<span class="syntax-keyword">return</span> (\n  &lt;button onClick={() =&gt; setCount(count + 1)}&gt;\n    {count}\n  &lt;/button&gt;\n)</code></pre></div><h2 id="prototype-boundary">An honest preview</h2><p>This counter is a prebuilt interaction in the style prototype. There is no MDX compiler or React runtime in this file, and opening source code never executes it.</p><p>The interface, however, is real: switch views, open another note, change the theme, and create a page without leaving the workspace.</p>`
  }];
  const defaults = {theme:'light',font:'sans',width:'standard',textSize:'normal',density:'comfortable',reducedMotion:false};
  let state = {prefs:{...defaults},newPages:[],overrides:{},deleted:[],checks:{},lastPage:'regression'};
  let storageAvailable = true;
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (saved && saved.version === 1) {
      for (const [key, allowed] of Object.entries({theme:['light','dark','system'],font:['sans','serif','mono'],width:['standard','wide','compact'],textSize:['small','normal','large'],density:['comfortable','compact']})) if (allowed.includes(saved.prefs?.[key])) state.prefs[key] = saved.prefs[key];
      if (typeof saved.prefs?.reducedMotion === 'boolean') state.prefs.reducedMotion = saved.prefs.reducedMotion;
      if (Array.isArray(saved.newPages)) state.newPages = saved.newPages.filter(p => p && /^new-[a-z0-9-]+$/.test(p.id) && typeof p.title === 'string').slice(0,100).map(p=>({id:p.id,title:p.title.slice(0,100),folder:folders.includes(p.folder)?p.folder:'Personal',template:['blank','lecture','project','copy'].includes(p.template)?p.template:'blank',baseId:seeded.some(s=>s.id===p.baseId)?p.baseId:null,note:typeof p.note==='string'?p.note.slice(0,100000):''}));
      if (saved.overrides && typeof saved.overrides==='object' && !Array.isArray(saved.overrides)) for(const [id,value] of Object.entries(saved.overrides)) if (seeded.some(p=>p.id===id) && value && typeof value.title==='string') state.overrides[id]={title:value.title.slice(0,100)};
      if (Array.isArray(saved.deleted)) state.deleted=saved.deleted.filter(x=>typeof x==='string');
      if (saved.checks && typeof saved.checks==='object') state.checks=Object.fromEntries(Object.entries(saved.checks).filter(([k,v])=>/^[a-z0-9_-]+$/.test(k)&&typeof v==='boolean'));
      if (typeof saved.lastPage==='string') state.lastPage=saved.lastPage;
    }
  } catch { storageAvailable=false; }
  let pageId = state.lastPage;
  let view = 'visual';
  let panelOpen = false;
  let panelTab = 'outline';
  let settingsTab = 'appearance';
  let selectedTemplate = 'blank';
  let dialogReturnFocus = null;
  let toastTimer;
  let scrollIndicatorTimer;
  let counter = 0;
  let searchIndex = 0;
  let currentResults = [];
  let deletedUndo = null;
  let popoverAnchor = null;
  const collapsedFolders = new Set();
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  const app = $('#app');
  const dialog = $('#app-dialog');
  const makeTemplate = p => {
    if(p.template==='copy' && seeded.some(s=>s.id===p.baseId)){const original=seeded.find(s=>s.id===p.baseId);return {...original,...p,updated:'Created in this browser',source:original.source.replace(/^# .*$/m,()=> '# '+p.title)};}
    const base={...p,icon:p.template==='project'?'layers':p.template==='lecture'?'book':'file',tag:p.template==='lecture'?'Lecture note':p.template==='project'?'Project plan':'New page',description:'A little space for your next idea.',updated:'Created in this browser',outline:[]};
    base.source=`# ${p.title}\n\n${p.note || ''}`;
    let intro='';
    if(p.template==='lecture'){intro='<h2 id="lecture-overview">Overview</h2><p>Capture the central idea, then make it your own.</p><h2 id="lecture-notes">Notes</h2>';base.outline=[{id:'lecture-overview',title:'Overview'},{id:'lecture-notes',title:'Notes'}];}
    if(p.template==='project'){intro='<h2 id="project-intent">What are we building?</h2><p>Start with the problem. Make the next step small and concrete.</p><h2 id="project-notes">Working notes</h2>';base.outline=[{id:'project-intent',title:'What are we building?'},{id:'project-notes',title:'Working notes'}];}
    base.body=intro+`<div class="blank-note"><label class="sr-only" for="new-note-body">Page content</label><textarea id="new-note-body" placeholder="Start writing…" spellcheck="true">${esc(p.note||'')}</textarea></div>`;
    return base;
  };
  const allPages = () => [...seeded.map(p=>({...p,...state.overrides[p.id],source:p.source.replace(/^# .*$/m,()=> '# '+(state.overrides[p.id]?.title||p.title))})),...state.newPages.map(makeTemplate)].filter(p=>!state.deleted.includes(p.id));
  const currentPage = () => allPages().find(p=>p.id===pageId);
  const wordCount = p => {const d=document.createElement('div');d.innerHTML=p.body;return (p.note || d.textContent || '').trim().split(/\s+/).filter(Boolean).length;};
  const fileName = p => p.title.normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,70) || 'untitled';
  function hydrateIcons(root=document) {root.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=icon(el.dataset.icon);el.removeAttribute('data-icon');});}
  function syncSidebar(focusOpen=false) {
    const mobile=innerWidth<=720,open=mobile?app.classList.contains('mobile-sidebar-open'):!app.classList.contains('sidebar-hidden')&&!app.classList.contains('focus-mode');
    $('#sidebar').inert=!open;$('#sidebar').setAttribute('aria-hidden',String(!open));
    $('#workspace').inert=mobile&&open;
    $('.sidebar-toggle').setAttribute('aria-expanded',String(open));$('.sidebar-toggle').setAttribute('aria-controls','sidebar');
    if(mobile&&open&&focusOpen)$('#sidebar .search-trigger').focus();
    if(!open&&$('#sidebar').contains(document.activeElement))$('.sidebar-toggle').focus();
  }
  function persist() {
    try {localStorage.setItem(STORAGE_KEY,JSON.stringify({version:1,...state}));storageAvailable=true;} catch {storageAvailable=false;}
  }
  function applyPreferences() {
    const p=state.prefs,root=document.documentElement;
    const actual=p.theme==='system'?(mediaQuery.matches?'dark':'light'):p.theme;
    root.dataset.theme=actual;root.dataset.font=p.font;root.dataset.width=p.width;root.dataset.textSize=p.textSize;root.dataset.density=p.density;root.dataset.motion=p.reducedMotion?'reduce':'normal';
    $$('.theme-option').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.theme===p.theme)));
  }
  function renderSidebar(highlightId) {
    const pages=allPages();
    const pageButton=p=>`<button class="nav-item nav-nested ${highlightId===p.id?'newly-created':''}" data-action="navigate" data-page="${esc(p.id)}" ${p.id===pageId?'aria-current="page"':''} title="${esc(p.title)}">${icon(p.icon)}<span>${esc(p.title)}</span></button>`;
    $('#page-tree').innerHTML=folders.map(folder=>`<section class="sidebar-section"><div class="section-label"><button class="folder-trigger" data-action="toggle-folder" data-folder="${folder}" aria-expanded="${!collapsedFolders.has(folder)}"><span class="folder-chevron">${icon(collapsedFolders.has(folder)?'chevron':'down')}</span><span class="folder-mark">${icon('folder')}</span><span>${folder}</span></button><button class="section-add" data-action="new-page" data-folder="${folder}" aria-label="New page in ${folder}">${icon('plus')}</button></div><div class="folder-children" data-folder-children="${folder}" ${collapsedFolders.has(folder)?'hidden':''}>${pages.filter(p=>p.folder===folder).map(pageButton).join('')||'<p class="menu-label">No pages yet.</p>'}</div></section>`).join('');
  }
  function renderPage(highlightId) {
    closePopover();
    app.classList.remove('mobile-sidebar-open');
    syncSidebar();
    renderSidebar(highlightId);
    const page=currentPage();
    if(!page){renderEmpty();return;}
    $('#document-content').innerHTML=`<article class="document-page"><header class="doc-header"><h1 class="doc-title" id="document-heading" tabindex="-1">${esc(page.title)}</h1>${page.id.startsWith('new-')?'':`<p class="doc-description">${esc(page.description)}</p>`}</header><div class="doc-body">${page.body}</div></article>`;
    mountCodeToolbars();
    $('#source-pane').innerHTML=`<pre class="source-code"><code>${highlightSource(page.source)}</code></pre>`;
    $('#document-scroller').scrollTop=0;
    $$('#document-content [data-check]').forEach(el=>{if(Object.hasOwn(state.checks,el.dataset.check))el.checked=state.checks[el.dataset.check];});
    counter=0;
    setView(view,false);
    renderPanel();
    updateFloatingStats();
    requestAnimationFrame(updateScrollIndicator);
    document.title=page.title+' · Programmable Notes';
    state.lastPage=pageId;persist();
  }
  function mountCodeToolbars() {
    $$('#document-content .code-block').forEach(block=>{
      const oldLabel=block.querySelector(':scope > .code-label');
      const label=oldLabel?.querySelector(':scope > span')?.textContent.trim()||oldLabel?.textContent.trim()||'Plain text';
      const language=/borrowed/i.test(label)?'Rust':label.split(/[·:]/)[0].trim();
      oldLabel?.remove();
      block.tabIndex=0;
      block.insertAdjacentHTML('afterbegin',`<div class="code-toolbar" role="group" aria-label="Code block actions"><button class="code-language" data-action="code-language" aria-label="Code language: ${esc(language)}" aria-haspopup="menu"><span>${esc(language)}</span>${icon('down')}</button><span class="code-toolbar-divider"></span><button data-action="copy-code" aria-label="Copy code" title="Copy code">${icon('copy')}</button><button data-action="code-wrap" aria-label="Wrap lines" aria-pressed="false" title="Wrap lines">${icon('return')}</button><button data-action="code-more" aria-label="More code actions" aria-haspopup="menu" title="More actions">${icon('more')}</button></div>`);
    });
  }
  function highlightSource(source) {
    return esc(source).split('\n').map(line=>{
      if(/^#{1,6} /.test(line))return `<span style="color:var(--ink);font-weight:600">${line}</span>`;
      if(/^(import|export|const|  const|  return|return)/.test(line))return `<span class="syntax-keyword">${line}</span>`;
      if(/^&gt;/.test(line))return `<span class="syntax-comment">${line}</span>`;
      if(/^&lt;|^```/.test(line))return `<span class="syntax-string">${line}</span>`;
      return line;
    }).join('\n');
  }
  function navigate(id,focus=false) {pageId=id;renderPage();if(focus)$('#document-heading')?.focus({preventScroll:true});}
  function renderEmpty() {
    view='visual';panelOpen=false;
    app.classList.remove('panel-open');
    $('#source-pane').hidden=true;$('#document-scroller').hidden=false;$('#details-panel').hidden=true;
    $('#document-content').innerHTML=`<section class="document-page empty-document"><h1 id="document-heading" tabindex="-1">No pages yet</h1><p>Create a page from the folder panel to begin.</p><button class="button" data-action="new-page">${icon('plus')} New page</button></section>`;
    updateFloatingStats();
    requestAnimationFrame(updateScrollIndicator);
    document.title='Programmable Notes';
  }
  function setView(next,announce=true) {
    if(!['visual','source'].includes(next))return;
    view=next;$('#editor-area').dataset.view=next;$('#mode-island').dataset.mode=next;$('#source-pane').hidden=next==='visual';$('#document-scroller').hidden=next==='source';
    $$('#mode-island-actions button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.view===next)));
    if(announce)updateFloatingStats();
    requestAnimationFrame(updateScrollIndicator);
  }
  function renderPanel() {
    const page=currentPage();
    app.classList.toggle('panel-open',panelOpen&&!!page);
    $('#outline-button').setAttribute('aria-expanded',String(panelOpen));$('#details-panel').hidden=!panelOpen||!page;
    if(!page||!panelOpen)return;
    $('#details-panel').innerHTML=`<div class="details-header"><strong>Document</strong></div><div class="panel-label">Outline</div><nav class="outline-nav" aria-label="Document outline">${page.outline.length?`<button data-action="outline" data-target="document-heading">${esc(page.title)}</button>${page.outline.map(o=>`<button data-action="outline" data-target="${esc(o.id)}">${esc(o.title)}</button>`).join('')}`:'<p class="panel-note">No headings yet.</p>'}</nav><div class="panel-label">Page actions</div><div class="panel-actions"><button data-action="rename">${icon('edit')}Rename</button><button data-action="duplicate">${icon('copy')}Duplicate</button><button data-action="export-page">${icon('download')}Export MDX</button><button data-action="delete">${icon('trash')}Move to trash</button></div>`;
  }
  function textCounts(value) {
    const content=String(value||'');
    return {words:content.trim()?content.trim().split(/\s+/u).length:0,characters:[...content].length,lines:content?content.split(/\r\n|\r|\n/u).length:0};
  }
  function updateFloatingStats() {
    const node=$('#floating-stats');
    const page=currentPage();
    if(!node)return;
    if(!page){node.textContent='';return;}
    let selection='';
    const active=document.activeElement;
    if(active?.id==='new-note-body'&&active.selectionStart!==active.selectionEnd){
      selection=active.value.slice(active.selectionStart,active.selectionEnd);
    }else{
      const sel=window.getSelection();
      const area=view==='source'?$('#source-pane'):$('#document-content');
      if(sel&&!sel.isCollapsed&&area?.contains(sel.anchorNode)&&area.contains(sel.focusNode))selection=sel.toString();
    }
    const selected=selection.length>0;
    const c=textCounts(selected?selection:page.source);
    node.innerHTML=`${selected?'<span class="stats-selection">Selected</span>':''}<span>${c.words.toLocaleString()} ${c.words===1?'word':'words'}</span><span>${c.characters.toLocaleString()} ${c.characters===1?'character':'characters'}</span><span>${c.lines.toLocaleString()} ${c.lines===1?'line':'lines'}</span>`;
  }
  function updateScrollIndicator() {
    const rail=$('#scroll-rail');
    const region=view==='visual'?$('#document-scroller'):$('#source-pane .source-code');
    if(!rail||!region){if(rail)rail.hidden=true;return;}
    const scrollable=region.scrollHeight-region.clientHeight;
    rail.hidden=scrollable<=1;
    if(rail.hidden)return;
    const trackHeight=rail.clientHeight;
    const thumbHeight=Math.max(28,Math.min(trackHeight,trackHeight*region.clientHeight/region.scrollHeight));
    const offset=(trackHeight-thumbHeight)*region.scrollTop/scrollable;
    const thumb=rail.querySelector('.scroll-thumb');
    thumb.style.height=thumbHeight+'px';
    thumb.style.transform=`translateY(${offset}px)`;
  }
  function revealScrollIndicator() {
    updateScrollIndicator();
    const rail=$('#scroll-rail');
    rail.classList.add('is-scrolling');
    clearTimeout(scrollIndicatorTimer);
    scrollIndicatorTimer=setTimeout(()=>rail.classList.remove('is-scrolling'),850);
  }
  function toast(message,name='check',undo=false) {clearTimeout(toastTimer);$('#toast-region').innerHTML=`<div class="toast">${icon(name)}<span>${esc(message)}</span>${undo?'<button data-action="undo-delete">Undo</button>':''}</div>`;toastTimer=setTimeout(()=>{$('#toast-region').innerHTML='';},undo?7000:3200);}
  function openDialog(html,className='',focusSelector='input,button') {
    closePopover();
    if(!dialog.open)dialogReturnFocus=document.activeElement;
    dialog.className='app-dialog '+className;dialog.innerHTML=html;
    if(dialog.querySelector('#dialog-title')){dialog.setAttribute('aria-labelledby','dialog-title');dialog.removeAttribute('aria-label');}else{dialog.removeAttribute('aria-labelledby');dialog.setAttribute('aria-label','Workspace dialog');}
    if(!dialog.open)dialog.showModal();
    requestAnimationFrame(()=>dialog.querySelector(focusSelector)?.focus());
  }
  function closeDialog(){if(dialog.open)dialog.close();}
  dialog.addEventListener('close',()=>{if(dialogReturnFocus?.isConnected)dialogReturnFocus.focus({preventScroll:true});else $('.sidebar-add')?.focus({preventScroll:true});});
  dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeDialog();}});
  function dialogHeader(title,desc){return `<div class="dialog-header"><div><h2 id="dialog-title">${title}</h2><p>${desc}</p></div><button class="icon-button" data-action="close-dialog" aria-label="Close dialog">${icon('close')}</button></div>`;}
  function newPage(folder='Personal') {
    selectedTemplate='blank';
    openDialog(`${dialogHeader('New page','')}<form id="new-page-form"><div class="dialog-body"><div class="field-group"><label class="field-label" for="new-title">Title</label><input id="new-title" class="text-field" type="text" placeholder="Untitled" maxlength="100" autocomplete="off" required><p class="form-error" id="new-page-error" role="alert" hidden></p></div><div class="field-group"><label class="field-label" for="new-folder">Folder</label><select class="text-field" id="new-folder">${folders.map(f=>`<option ${folder===f?'selected':''}>${f}</option>`).join('')}</select></div></div><div class="dialog-footer"><button class="button" type="button" data-action="close-dialog">Cancel</button><button class="button primary" type="submit">Create page</button></div></form>`,'new-page-dialog','#new-title');
    dialog.setAttribute('aria-labelledby','dialog-title');
  }
  function createPage(event) {
    event.preventDefault();
    const input=$('#new-title');if(!input)return;
    const title=input.value.trim();
    if(!title){$('#new-page-error').hidden=false;$('#new-page-error').textContent='Give your page a title before creating it.';input.focus();return;}
    const id='new-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);
    state.newPages.push({id,title,folder:$('#new-folder').value,template:selectedTemplate,note:''});
    closeDialog();pageId=id;view='visual';collapsedFolders.delete(state.newPages.at(-1).folder);renderPage(id);persist();toast('Your new page is ready.');requestAnimationFrame(()=>$('#new-note-body')?.focus());
  }
  function openSearch(){searchIndex=0;openDialog(`<div class="search-input-row">${icon('search')}<input type="search" id="search-input" aria-label="Search pages" placeholder="Find a note, an idea, a page…" autocomplete="off"><button class="icon-button" data-action="close-dialog" aria-label="Close search">${icon('close')}</button></div><div class="search-results" id="search-results" aria-label="Search results"></div><div class="search-footer"><span><kbd>↑</kbd><kbd>↓</kbd> to navigate</span><span><kbd>Enter</kbd> to open</span><span><kbd>Esc</kbd> to close</span></div>`,'search-dialog','#search-input');dialog.removeAttribute('aria-labelledby');dialog.setAttribute('aria-label','Search pages');renderSearch('');}
  function renderSearch(query){const q=query.trim().toLowerCase();currentResults=allPages().filter(p=>(p.title+' '+p.folder+' '+p.description).toLowerCase().includes(q));searchIndex=Math.min(searchIndex,Math.max(0,currentResults.length-1));$('#search-results').innerHTML=currentResults.length?currentResults.map((p,i)=>`<button class="search-result ${i===searchIndex?'selected':''}" data-action="search-open" data-page="${p.id}">${icon(p.icon)}<span><strong>${esc(p.title)}</strong><small>${esc(p.folder)} · ${esc(p.tag)}</small></span>${icon('return')}</button>`).join(''):`<div class="empty-state">${icon('search')}<strong>No pages found</strong>Try a different title, subject, or folder.</div>`;}
  function openSettings(tab='appearance') {settingsTab=tab;renderSettings(true);}
  function renderSettings(initial=false) {
    const nav=[['appearance','sun','Appearance'],['editor','typography','Editor'],['workspace','folder','Workspace'],['shortcuts','command','Shortcuts'],['about','info','About']];
    const titles={appearance:'Make it feel like you.',editor:'A comfortable place to write.',workspace:'Your notes. Your workspace.',shortcuts:'Keep your hands on the keys.',about:'Made for thoughtful work.'};
    const descriptions={appearance:'A quiet interface, in the light that suits you.',editor:'Small adjustments for a more natural reading experience.',workspace:'A local-first design, with clear boundaries.',shortcuts:'A few shortcuts for the places you visit most.',about:'Programmable Notes · Visual prototype 01'};
    const html=`<div class="settings-layout"><nav class="settings-nav" aria-label="Settings sections"><h2>Settings</h2>${nav.map(([id,ic,label])=>`<button class="nav-item ${settingsTab===id?'active':''}" data-action="settings-tab" data-tab="${id}" ${settingsTab===id?'aria-current="page"':''}>${icon(ic)}<span>${label}</span></button>`).join('')}</nav><section class="settings-main"><div class="settings-title"><h2 id="dialog-title">${titles[settingsTab]}</h2><button class="icon-button" data-action="close-dialog" aria-label="Close settings">${icon('close')}</button></div><p class="settings-description">${descriptions[settingsTab]}</p>${settingsContent()}</section></div>`;
    if(initial)openDialog(html,'settings-dialog','.settings-main .icon-button');else{const scroll=$('.settings-main')?.scrollTop||0;dialog.innerHTML=html;$('.settings-main').scrollTop=scroll;}
    dialog.setAttribute('aria-labelledby','dialog-title');applyPreferences();
  }
  function selectControl(key,options,label){return `<select class="text-field" data-preference="${key}" aria-label="${label}">${options.map(([value,text])=>`<option value="${value}" ${state.prefs[key]===value?'selected':''}>${text}</option>`).join('')}</select>`;}
  function switchControl(key,label){return `<button class="switch" role="switch" aria-checked="${state.prefs[key]}" aria-label="${label}" data-action="preference-switch" data-preference="${key}"></button>`;}
  function settingsContent(){const p=state.prefs;switch(settingsTab){
    case 'appearance':return `<h3 class="settings-section-title" style="margin-top:0">Color theme</h3><div class="theme-options">${['light','dark','system'].map(t=>`<button class="theme-option" data-action="theme" data-theme="${t}" aria-pressed="${p.theme===t}"><div class="theme-thumbnail ${t}"></div><span class="theme-name">${t[0].toUpperCase()+t.slice(1)}${icon('check')}</span></button>`).join('')}</div><h3 class="settings-section-title">Layout &amp; movement</h3><div class="setting-row"><div><strong>Sidebar density</strong><small>Give your pages a little breathing room.</small></div>${selectControl('density',[['comfortable','Comfortable'],['compact','Compact']],'Sidebar density')}</div><div class="setting-row"><div><strong>Reduce motion</strong><small>Keep transitions simple and still.</small></div>${switchControl('reducedMotion','Reduce motion')}</div><div class="settings-note">${icon('check')}Theme and appearance changes apply immediately and stay in this browser when storage is available.</div>`;
    case 'editor':return `<div class="setting-row"><div><strong>Document typeface</strong><small>A different rhythm for the same words.</small></div>${selectControl('font',[['sans','Sans serif'],['serif','Serif'],['mono','Monospace']],'Document typeface')}</div><div class="setting-row"><div><strong>Text size</strong><small>Set your comfortable reading size.</small></div>${selectControl('textSize',[['small','Small'],['normal','Default'],['large','Large']],'Text size')}</div><div class="setting-row"><div><strong>Content width</strong><small>Keep a focused measure, or spread out.</small></div>${selectControl('width',[['compact','Focused'],['standard','Default'],['wide','Wide']],'Content width')}</div><div class="settings-note">${icon('info')}Preview and Source are available from the small handle at the top of the document.</div>`;
    case 'workspace':return `<div class="setting-row"><div><strong>Personal workspace</strong><small>${allPages().length} pages · ${state.newPages.length} created by you in this demo</small></div><span class="tag green">Browser local</span></div><h3 class="settings-section-title">Future connections</h3><div class="integration-row">${icon('github')}<div><strong>Git &amp; GitHub</strong><small>Version history and an optional remote.</small></div><span class="tag">Not connected</span></div><div class="integration-row">${icon('cloud')}<div><strong>Google Drive</strong><small>An optional connection, later.</small></div><span class="tag">Not connected</span></div><div class="settings-note">${icon('lock')}This is a frontend prototype. There are no accounts, cloud sync, native file permissions, real Git operations, or background AI requests.</div><button class="button" data-action="export-workspace">${icon('download')} Export demo pages</button><p class="field-hint">Downloads a JSON copy of your demo pages and preferences.</p>`;
    case 'shortcuts':return [['Find a page',keyName+' K'],['Create a page','Alt N'],['Open settings',keyName+' ,'],['Toggle navigation',keyName+' \\'],['Export current note',keyName+' S'],['Show these shortcuts','?'],['Dismiss a menu or dialog','Esc']].map(([a,b])=>`<div class="shortcut-row"><span>${a}</span><kbd>${b}</kbd></div>`).join('')+'<p class="field-hint" style="margin-top:20px">Use Tab to move through controls. Arrow keys switch view tabs and navigate search results.</p>';
    default:return `<div class="prototype-about"><div class="brand-mark"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 5.5h16L12 20 4 5.5Z" stroke="currentColor" stroke-width="1.65"/><path d="m8.2 5.5 3.8 7 3.8-7" stroke="currentColor" stroke-width="1.65"/></svg></div><h3>Ideas deserve a good home.</h3><p>A minimal visual direction for Programmable Notes.</p><p>This single HTML file works offline. The supplied notes are examples.</p><div class="settings-note"><strong>Working:</strong> folder navigation, search, new pages, draft text, themes, settings, and page actions.<br><strong>Simulated:</strong> MDX compilation, native storage, sync, version control, and AI.</div></div>`;
  }}
  function closePopover(){const wasOpen=$('#popover-root').childElementCount>0;$('#popover-root').innerHTML='';$('.profile').setAttribute('aria-expanded','false');return wasOpen;}
  function popover(html,anchor){const wasOpen=$('#popover-root').childElementCount>0;closePopover();if(wasOpen)return;popoverAnchor=anchor;$('#popover-root').innerHTML=`<div class="popover" role="menu">${html}</div>`;const el=$('.popover'),r=anchor.getBoundingClientRect();el.style.top=Math.min(r.bottom+7,window.innerHeight-el.offsetHeight-12)+'px';el.style.left=Math.min(Math.max(12,r.left),window.innerWidth-el.offsetWidth-12)+'px';anchor.setAttribute('aria-expanded','true');el.querySelector('button')?.focus();}
  function rename(){const p=currentPage();if(!p)return;openDialog(`${dialogHeader('Give it a name.','The note stays in the same place.')}<form id="rename-form"><div class="dialog-body"><label class="field-label" for="rename-title">Page title</label><input class="text-field" id="rename-title" value="${esc(p.title)}" maxlength="100" required></div><div class="dialog-footer"><button type="button" class="button" data-action="close-dialog">Cancel</button><button type="submit" class="button primary">Rename page</button></div></form>`,'','#rename-title');requestAnimationFrame(()=>$('#rename-title').select());}
  function updateTitle(event){event.preventDefault();const value=$('#rename-title')?.value.trim();if(!value){$('#rename-title')?.focus();return;}const p=state.newPages.find(x=>x.id===pageId);if(p)p.title=value;else state.overrides[pageId]={title:value};closeDialog();renderPage();persist();toast('Page renamed.');}
  function duplicate(){const p=currentPage();if(!p)return;const newId='new-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);const isSeed=seeded.some(s=>s.id===p.id);state.newPages.push({id:newId,title:p.title+' (copy)',folder:p.folder,template:isSeed||p.baseId?'copy':p.template||'blank',baseId:isSeed?p.id:p.baseId||null,note:p.note||''});pageId=newId;view='visual';collapsedFolders.delete(p.folder);renderPage(newId);persist();toast('Page duplicated.');}
  function confirmDelete(){const p=currentPage();if(!p)return;openDialog(`${dialogHeader('Move this page to trash?','Only the copy inside this prototype will be removed.')}<div class="dialog-body"><p style="font-size:13px;margin:0">${esc(p.title)}</p><p class="field-hint">You can undo immediately, or restore it from the workspace menu.</p></div><div class="dialog-footer"><button class="button" data-action="close-dialog">Keep page</button><button class="button danger" data-action="confirm-delete">Move to trash</button></div>`,'','.dialog-footer button');}
  function moveToTrash(){const p=currentPage();if(!p)return;deletedUndo=p.id;state.deleted.push(p.id);closeDialog();navigate(allPages()[0]?.id||'empty');persist();toast('Page moved to trash.','trash',true);}
  function trashView(){const removed=[...seeded,...state.newPages.map(makeTemplate)].filter(p=>state.deleted.includes(p.id));openDialog(`${dialogHeader('A little room to reconsider.','Deleted demo pages stay here until you restore them.')}<div class="dialog-body">${removed.length?removed.map(p=>`<div class="setting-row"><div><strong>${esc(state.overrides[p.id]?.title||p.title)}</strong><small>${esc(p.folder)}</small></div><button class="button" data-action="restore-page" data-page="${p.id}">Restore</button></div>`).join(''):'<div class="empty-state">'+icon('trash')+'<strong>Nothing in the trash</strong>Your notes are right where you left them.</div>'}</div><div class="dialog-footer"><button class="button" data-action="close-dialog">Done</button></div>`,'','.dialog-header button');}
  function download(content,name,mime){const blob=new Blob([content],{type:mime});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function exportPage(){const p=currentPage();if(!p){toast('Open a note to export it.','info');return;}download(p.source,fileName(p)+'.mdx','text/plain;charset=utf-8');toast('MDX download requested.');closePopover();}
  async function copyText(text){try{await navigator.clipboard.writeText(text);toast('Copied to clipboard.');}catch{openDialog(`${dialogHeader('Copy this text.','Clipboard access is unavailable here. Select and copy below.')}<div class="dialog-body"><textarea id="copy-fallback" class="text-field" style="min-height:200px;font-family:monospace" readonly>${esc(text)}</textarea></div><div class="dialog-footer"><button class="button" data-action="close-dialog">Done</button></div>`,'','#copy-fallback');requestAnimationFrame(()=>$('#copy-fallback').select());}}
  document.addEventListener('click',event=>{
    if(!event.target.closest('#mode-island')){
      $('#mode-island').classList.remove('is-open');
      $('.mode-island-handle').setAttribute('aria-expanded','false');
    }
    const button=event.target.closest('[data-action]');
    if(!button){if(!event.target.closest('.popover'))closePopover();return;}
    const action=button.dataset.action;
    if(action!=='workspace-menu')closePopover();
    switch(action){
      case 'navigate':navigate(button.dataset.page);break;
      case 'new-page':newPage(button.dataset.folder||'Personal');break;
      case 'search':openSearch();break;
      case 'search-open':closeDialog();navigate(button.dataset.page,true);break;
      case 'settings':openSettings();break;
      case 'shortcuts':openSettings('shortcuts');break;
      case 'about':openSettings('about');break;
      case 'settings-tab':settingsTab=button.dataset.tab;renderSettings();dialog.querySelector(`[data-tab="${settingsTab}"]`)?.focus();break;
      case 'theme':state.prefs.theme=button.dataset.theme;applyPreferences();persist();break;
      case 'preference-switch':{const key=button.dataset.preference;state.prefs[key]=!state.prefs[key];button.setAttribute('aria-checked',String(state.prefs[key]));applyPreferences();persist();break;}
      case 'view':setView(button.dataset.view);$('#mode-island').classList.remove('is-open');$('.mode-island-handle').setAttribute('aria-expanded','false');if(event.detail)button.blur();break;
      case 'toggle-mode-island':{const island=$('#mode-island');const open=island.classList.toggle('is-open');button.setAttribute('aria-expanded',String(open));break;}
      case 'close-dialog':closeDialog();break;
      case 'toggle-sidebar':if(innerWidth<=720)app.classList.toggle('mobile-sidebar-open');else app.classList.toggle('sidebar-hidden');syncSidebar(true);break;
      case 'close-sidebar':app.classList.remove('mobile-sidebar-open');syncSidebar();$('.sidebar-toggle').focus();break;
      case 'toggle-folder':{const expanded=button.getAttribute('aria-expanded')==='true';if(expanded)collapsedFolders.add(button.dataset.folder);else collapsedFolders.delete(button.dataset.folder);button.setAttribute('aria-expanded',String(!expanded));document.querySelector(`[data-folder-children="${button.dataset.folder}"]`).hidden=expanded;button.querySelector('.folder-chevron svg').outerHTML=icon(expanded?'chevron':'down');break;}
      case 'toggle-panel':panelOpen=!panelOpen;renderPanel();break;
      case 'panel-tab':panelTab=button.dataset.tab;renderPanel();$(`#details-panel [data-tab="${panelTab}"]`)?.focus();break;
      case 'outline':{if(view==='source')setView('visual',false);document.getElementById(button.dataset.target)?.scrollIntoView({behavior:state.prefs.reducedMotion?'instant':'smooth',block:'start'});if(innerWidth<=960){panelOpen=false;renderPanel();}break;}
      case 'workspace-menu':popover(`<button class="menu-item" role="menuitem" data-action="settings">${icon('settings')}Settings</button><button class="menu-item" role="menuitem" data-action="trash">${icon('trash')}Trash${state.deleted.length?' ('+state.deleted.length+')':''}</button><div class="menu-separator"></div><button class="menu-item" role="menuitem" data-action="about">${icon('info')}About</button>`,button);break;
      case 'rename':rename();break;
      case 'duplicate':duplicate();break;
      case 'delete':confirmDelete();break;
      case 'confirm-delete':moveToTrash();break;
      case 'trash':trashView();break;
      case 'restore-page':state.deleted=state.deleted.filter(id=>id!==button.dataset.page);persist();renderSidebar();trashView();toast('Page restored.');break;
      case 'undo-delete':if(deletedUndo){state.deleted=state.deleted.filter(id=>id!==deletedUndo);navigate(deletedUndo);persist();deletedUndo=null;toast('Page restored.');}break;
      case 'export-page':exportPage();break;
      case 'export-workspace':download(JSON.stringify({prototype:'Programmable Notes style v1',pages:allPages().map(({id,title,folder,source})=>({id,title,folder,source})),preferences:state.prefs},null,2),'programmable-notes-demo.json','application/json');toast('Workspace download requested.');break;
      case 'copy-source':copyText(currentPage()?.source||'');break;
      case 'copy-code':copyText(button.closest('.code-block').querySelector('code').textContent);break;
      case 'code-wrap':{const block=button.closest('.code-block');const wrapped=block.classList.toggle('code-wrapped');block.querySelector('[data-action="code-wrap"]').setAttribute('aria-pressed',String(wrapped));break;}
      case 'code-language':popover(['Plain text','JavaScript','TypeScript','JSX','Python','R','Rust','SQL','Pseudocode'].map(lang=>`<button class="menu-item" role="menuitem" data-action="code-set-language" data-language="${esc(lang)}">${esc(lang)}</button>`).join(''),button);break;
      case 'code-set-language':{const block=popoverAnchor?.closest('.code-block');const language=block?.querySelector('.code-language');if(language){language.querySelector('span').textContent=button.dataset.language;language.setAttribute('aria-label','Code language: '+button.dataset.language);language.focus();}break;}
      case 'code-more':popover(`<button class="menu-item" role="menuitem" data-action="code-more-copy">${icon('copy')}Copy code</button><button class="menu-item" role="menuitem" data-action="code-more-wrap">${icon('return')}Toggle line wrapping</button>`,button);break;
      case 'code-more-copy':{const block=popoverAnchor?.closest('.code-block');if(block)copyText(block.querySelector('code').textContent);break;}
      case 'code-more-wrap':{const block=popoverAnchor?.closest('.code-block');block?.querySelector('[data-action="code-wrap"]')?.click();break;}
      case 'explore-fit':{const c=$('#fit-controls');c.hidden=!c.hidden;button.setAttribute('aria-expanded',String(!c.hidden));if(!c.hidden)$('#slope-slider').focus();break;}
      case 'reset-slope':$('#slope-slider').value='1';$('#slope-slider').dispatchEvent(new Event('input',{bubbles:true}));break;
      case 'counter-up':$('#demo-count').textContent=++counter;break;
      case 'counter-down':$('#demo-count').textContent=--counter;break;
      case 'reference':openDialog(`${dialogHeader('Reference preview','Example material, not an uploaded course document.')}<div class="dialog-body"><div class="doc-body"><h2>Understanding a model</h2><p>A model simplifies a relationship so that we can reason about it. Check the assumptions, examine the residuals, and be explicit about uncertainty.</p><blockquote>This panel keeps a reference close without taking you away from your notes.</blockquote></div></div><div class="dialog-footer"><button class="button" data-action="close-dialog">Back to the note</button></div>`);break;
    }
  });
  document.addEventListener('submit',event=>{if(event.target.id==='new-page-form')createPage(event);if(event.target.id==='rename-form')updateTitle(event);});
  document.addEventListener('pointerdown',event=>{
    if(event.pointerType!=='touch')return;
    const block=event.target.closest('.code-block');
    $$('.code-block[data-tools-open="true"]').forEach(other=>{if(other!==block)other.dataset.toolsOpen='false';});
    if(block&&!event.target.closest('.code-toolbar'))block.dataset.toolsOpen=block.dataset.toolsOpen==='true'?'false':'true';
  });
  document.addEventListener('input',event=>{
    if(event.target.id==='search-input'){searchIndex=0;renderSearch(event.target.value);}
    if(event.target.id==='slope-slider'){const slope=Number(event.target.value);$('#slope-output').value=slope.toFixed(2);$('#regression-line').setAttribute('d',`M64 ${113+65*slope} 590 ${113-65*slope}`);}
    if(event.target.id==='new-note-body'){const p=state.newPages.find(x=>x.id===pageId);if(p){p.note=event.target.value;persist();const source=$('.source-code code');if(source)source.innerHTML=highlightSource('# '+p.title+'\n\n'+p.note);updateFloatingStats();}}
  });
  document.addEventListener('selectionchange',updateFloatingStats);
  document.addEventListener('select',event=>{if(event.target.id==='new-note-body')updateFloatingStats();});
  for(const region of [$('#document-scroller'),$('#source-pane')]){
    region.addEventListener('pointerenter',()=>{$('#scroll-rail').classList.add('is-hover');updateScrollIndicator();});
    region.addEventListener('pointerleave',()=>$('#scroll-rail').classList.remove('is-hover'));
  }
  document.addEventListener('scroll',event=>{if(event.target.id==='document-scroller'||event.target.matches?.('.source-code'))revealScrollIndicator();},true);
  document.addEventListener('change',event=>{
    if(event.target.matches('select[data-preference]')){state.prefs[event.target.dataset.preference]=event.target.value;applyPreferences();persist();}
    if(event.target.matches('[data-check]')){state.checks[event.target.dataset.check]=event.target.checked;persist();}
  });
  document.addEventListener('keydown',event=>{
    const editing=/INPUT|TEXTAREA|SELECT/.test(event.target.tagName)||event.target.isContentEditable;
    const mod=event.ctrlKey||event.metaKey;
    if(event.key==='Escape'){if(!dialog.open){const was=closePopover();$('#mode-island').classList.remove('is-open');$('.mode-island-handle').setAttribute('aria-expanded','false');if(was)popoverAnchor?.focus();else{app.classList.remove('mobile-sidebar-open','focus-mode');syncSidebar();}}return;}
    if(event.key==='Tab'&&!dialog.open&&innerWidth<=720&&app.classList.contains('mobile-sidebar-open')){const controls=[$('.sidebar-scrim'),...$$('#sidebar button,#sidebar input')].filter(el=>!el.hidden&&el.getClientRects().length);const first=controls[0],last=controls.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}
    if(mod&&event.key.toLowerCase()==='k'){event.preventDefault();openSearch();return;}
    if(mod&&event.key===','){event.preventDefault();openSettings();return;}
    if(mod&&event.key==='\\'&&!dialog.open){event.preventDefault();$('.sidebar-toggle').click();return;}
    if(mod&&event.key.toLowerCase()==='s'&&!dialog.open){event.preventDefault();exportPage();return;}
    if(event.altKey&&event.key.toLowerCase()==='n'&&!dialog.open){event.preventDefault();newPage();return;}
    if(event.key==='?'&&!editing&&!dialog.open){event.preventDefault();openSettings('shortcuts');return;}
    if(event.target.id==='search-input'&&['ArrowUp','ArrowDown','Enter'].includes(event.key)){event.preventDefault();if(event.key==='Enter'){if(currentResults[searchIndex]){const id=currentResults[searchIndex].id;closeDialog();navigate(id,true);}}else{searchIndex=(searchIndex+(event.key==='ArrowDown'?1:-1)+Math.max(1,currentResults.length))%Math.max(1,currentResults.length);renderSearch(event.target.value);$$('.search-result')[searchIndex]?.scrollIntoView({block:'nearest'});}return;}
    if(event.target.matches('.mode-island-actions button')&&['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();const buttons=$$('.mode-island-actions button');let i=buttons.indexOf(event.target);i=event.key==='Home'?0:event.key==='End'?buttons.length-1:(i+(event.key==='ArrowRight'?1:buttons.length-1))%buttons.length;buttons[i].focus();setView(buttons[i].dataset.view,false);}
    if(event.target.closest('.popover')&&['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();const buttons=$$('.popover button');let i=buttons.indexOf(event.target);buttons[(i+(event.key==='ArrowDown'?1:buttons.length-1))%buttons.length]?.focus();}
  });
  window.addEventListener('resize',()=>{closePopover();if(innerWidth>720)app.classList.remove('mobile-sidebar-open');syncSidebar();requestAnimationFrame(updateScrollIndicator);});
  mediaQuery.addEventListener('change',()=>{if(state.prefs.theme==='system')applyPreferences();});
  hydrateIcons();
  $$('[data-shortcut]').forEach(el=>{el.textContent=el.dataset.shortcut.startsWith('Alt')?el.dataset.shortcut:keyName+' '+el.dataset.shortcut;});
  if(!allPages().some(p=>p.id===pageId))pageId='regression';
  applyPreferences();renderPage();
})();
