# Programmable Notes visual prototype: acceptance checklist

This is a frontend specification and test aid, not evidence of passing tests.

## State contract

- At most one active page, main route, document view mode and theme.
- A selected page has one stable ID. Titles are display labels, not identifiers.
- Search, settings, creation and page-action overlays must not compete for focus.
- The page content, breadcrumb, sidebar selection and outline describe the same page.
- Changing a view mode never changes the source or creates another page.
- Page creation is the only operation in the creation dialog that adds a page. Opening, previewing a template and cancelling are side-effect free.
- Backend operations remain simulated and are labelled as such.

## P0: essential interactions

| Scenario | Expected behavior |
| --- | --- |
| First launch | A seeded page is visible; all major controls have names and visible states. |
| Navigate every sidebar item | Active route, title, content and outline agree. No blank or stale page. |
| New page: cancel | No page or navigation change; focus returns to the triggering button. |
| New page: whitespace title | Validation prevents an empty visible title or deliberately uses a visible `Untitled` default. |
| New page: confirm twice | One page is created per confirmed interaction, not a duplicate from two event handlers. |
| New page: duplicate title | Both pages remain distinguishable by stable IDs; navigation does not overwrite the old page. |
| New page: special characters | `<`, `>`, `&`, quotes and Unicode are displayed as literal text, never executed as HTML. |
| Template selection | Selection is apparent and changes the creation result; cancel does not add template pages. |
| Light/dark switch with dialog open | App, overlay, dialog, inputs, menus and code surfaces switch together. |
| Settings | Every enabled control has a visible, reversible effect; unavailable operations are disabled or clearly simulated. |
| Search a page and activate it | Correct page opens, search closes, selection updates and focus is sensible. |
| Empty search | Clearly communicates no results and allows clearing or closing. |
| Page rename | All title-dependent surfaces update; the page ID and route remain stable. |
| Page deletion, if offered | Explicit confirmation or recoverable trash; deleting the active page selects a valid fallback. |
| Source/Split/Visual modes | No unwanted content mutation. A simulated source view must not claim to compile or execute arbitrary React. |

## P1: corner cases and resilience

- Close each modal using its button, Escape and backdrop, where supported. Clicking inside must not dismiss it.
- Open a nested menu over a dialog and press Escape. Only the top layer closes first.
- Keyboard focus must remain in a modal and return to the trigger. Focus must not disappear after rerendering.
- Rapidly switch page, view mode and theme. The UI must end in one coherent state.
- Close the mobile sidebar by choosing a page, pressing Escape or tapping the backdrop. Resizing back to desktop restores usable navigation.
- Open the app with an unknown or stale route. Render a usable fallback, not an exception or empty main pane.
- Try long page titles, a long unbroken word, long code lines, 15 search results and an empty workspace state.
- Check whether favorites and page actions update duplicate sidebar representations consistently.
- Outline links must scroll to actual headings, including after changing pages. No stale heading targets.
- Resources and attachments must either open a supplied resource or clearly show a mock preview. No misleading empty downloads.
- If localStorage is used: test refresh, malformed JSON, missing stored fields, storage denial and quota failure. Preserve the initial seeded experience as a safe fallback.
- Persistent edits require a versioned storage key so future prototype revisions do not crash on an older shape.
- Import or source text must never be evaluated merely to support this visual prototype.

## Visual and accessibility checks

- Review at 1440, 1024, 768, 390 and 320 px widths, plus 200% zoom.
- Verify no horizontal document overflow; code blocks may scroll within their own region.
- Ensure all primary actions are reachable on mobile, including theme, settings and new page.
- Check light and dark contrast on muted text, selected items, borders, placeholder text and focus rings.
- Icon-only controls need accessible names. Toggle controls expose pressed/checked state; disclosure controls expose expanded state.
- Use semantic buttons and links, not click-only anonymous divs. Visible text inputs have labels.
- Respect `prefers-reduced-motion`; page creation still gives understandable confirmation with animation reduced.
- Primary document content must not be duplicated in a second rendered panel by default.

## Prototype language: avoid misleading claims

| Avoid unless real | Safer mockup language |
| --- | --- |
| `Synced`, `GitHub connected`, `All changes pushed` | `Sync preview`, `GitHub integration preview`, `Not connected in this prototype` |
| `Saved to your computer` when only localStorage is used | `Saved in this browser` |
| `End-to-end encrypted`, `Sandbox secured` | Do not display security guarantees in a visual prototype. |
| `Live React preview` for hardcoded HTML | `Component preview` or `Example React document` |
| `AI is thinking` when no model runs | `Example suggestion` or `AI interaction preview` |
| `Shared with your team` without a backend | `Share dialog preview` |
| Real-looking cloud or Git success toast | A clearly marked simulated interaction, with no claim that external state changed. |

## Evidence recording

Record actual pass/fail results separately from this checklist, including the tested HTML hash, browser, viewport, theme and any inaccessible interaction. Static inspection is not an interactive pass.
