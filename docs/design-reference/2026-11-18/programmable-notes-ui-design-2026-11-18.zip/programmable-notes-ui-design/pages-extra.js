window.EXTRA_PAGES = [
  {
    id: 'algorithms',
    title: 'Algorithms & complexity',
    icon: 'braces',
    folder: 'Ensimag',
    tag: 'Computer science',
    description: 'Think about growth before counting seconds.',
    updated: 'Sample note',
    outline: [
      { id: 'algorithms-growth', title: 'How the work grows' },
      { id: 'algorithms-comparison', title: 'Two ways to search' },
      { id: 'algorithms-checkpoint', title: 'A useful checkpoint' }
    ],
    source: '# Algorithms & complexity\n\nThink about growth before counting seconds.\n\n## How the work grows\n\nComplexity describes how an algorithm behaves as the input grows. It helps us compare approaches without tying the explanation to a particular machine.\n\n- O(1): the number of operations stays bounded.\n- O(log n): each step removes a fixed fraction of the remaining work.\n- O(n): work grows in proportion to the input.\n- O(n²): doubling the input can multiply the dominant work by four.\n\n## Two ways to search\n\nA linear search can inspect every item. Binary search repeatedly halves a sorted search range.\n\n```text\nwhile low <= high:\n  middle = low + (high - low) // 2\n  compare target with values[middle]\n  keep the half that may contain target\n```\n\nBinary search needs sorted data and efficient access to the middle element. Its logarithmic comparison count does not make those requirements disappear.\n\n## A useful checkpoint\n\n- [x] Identify the input size.\n- [ ] Choose the operation being counted.\n- [ ] Explain the worst case in one sentence.\n\nStart with a clear invariant, then prove that each iteration makes progress.\n',
    body: `
      <h2 id="algorithms-growth">How the work grows</h2>
      <p>Complexity describes how an algorithm behaves as the input grows. It helps us compare approaches without tying the explanation to a particular machine.</p>
      <ul>
        <li><code>O(1)</code>: the number of operations stays bounded.</li>
        <li><code>O(log n)</code>: each step removes a fixed fraction of the remaining work.</li>
        <li><code>O(n)</code>: work grows in proportion to the input.</li>
        <li><code>O(n²)</code>: doubling the input can multiply the dominant work by four.</li>
      </ul>
      <h2 id="algorithms-comparison">Two ways to search</h2>
      <p>A linear search can inspect every item. Binary search repeatedly halves a sorted search range.</p>
      <div class="code-block"><div class="code-label">Pseudocode</div><pre><code>while low &lt;= high:
  middle = low + (high - low) // 2
  compare target with values[middle]
  keep the half that may contain target</code></pre></div>
      <div class="note-callout"><span class="callout-label">The important assumption</span><p>Binary search needs sorted data and efficient access to the middle element. Its logarithmic comparison count does not make those requirements disappear.</p></div>
      <h2 id="algorithms-checkpoint">A useful checkpoint</h2>
      <div class="check-list">
        <label class="checklist-row"><input type="checkbox" data-check="algorithms-size" checked>Identify the input size.</label>
        <label class="checklist-row"><input type="checkbox" data-check="algorithms-operation">Choose the operation being counted.</label>
        <label class="checklist-row"><input type="checkbox" data-check="algorithms-worst-case">Explain the worst case in one sentence.</label>
      </div>
      <p class="subtle">Start with a clear invariant, then prove that each iteration makes progress.</p>`
  },
  {
    id: 'rust',
    title: 'Ownership in Rust',
    icon: 'code',
    folder: 'Ensimag',
    tag: 'Programming',
    description: 'A small mental model for values, moves, and borrowing.',
    updated: 'Sample note',
    outline: [
      { id: 'rust-ownership', title: 'One owner at a time' },
      { id: 'rust-borrowing', title: 'Borrow instead of moving' },
      { id: 'rust-practice', title: 'Before reaching for clone' }
    ],
    source: '# Ownership in Rust\n\nA small mental model for values, moves, and borrowing.\n\n## One owner at a time\n\nA value has an owner. When that owner goes out of scope, Rust drops the value. Moving an owned String into another binding makes the previous binding unavailable.\n\n```rust\nlet first = String::from("hello");\nlet second = first;\n// first is no longer available here\nprintln!("{second}");\n```\n\nA move transfers ownership. It does not automatically duplicate the heap allocation.\n\n## Borrow instead of moving\n\nA reference lets a function use a value without taking ownership. For a shared reference, the function can read the value while the caller keeps ownership.\n\n```rust\nfn letter_count(text: &str) -> usize {\n    text.chars().count()\n}\n```\n\nWhile a mutable reference is in use, no competing references may access the same value. The compiler checks these relationships.\n\n## Before reaching for clone\n\nAsk whether the function needs to own the value, change it, or merely read it. The answer usually suggests the parameter type.\n\n- [ ] Trace where a value moves.\n- [ ] Replace an unnecessary clone with a borrow.\n- [ ] Explain when the value is dropped.\n',
    body: `
      <h2 id="rust-ownership">One owner at a time</h2>
      <p>A value has an owner. When that owner goes out of scope, Rust drops the value. Moving an owned <code>String</code> into another binding makes the previous binding unavailable.</p>
      <div class="code-block"><div class="code-label">Rust</div><pre><code>let first = String::from("hello");
let second = first;
// first is no longer available here
println!("{second}");</code></pre></div>
      <p>A move transfers ownership. It does not automatically duplicate the heap allocation.</p>
      <h2 id="rust-borrowing">Borrow instead of moving</h2>
      <p>A reference lets a function use a value without taking ownership. For a shared reference, the function can read the value while the caller keeps ownership.</p>
      <div class="code-block"><div class="code-label">A borrowed parameter</div><pre><code>fn letter_count(text: &amp;str) -&gt; usize {
    text.chars().count()
}</code></pre></div>
      <div class="note-callout"><span class="callout-label">A useful rule</span><p>While a mutable reference is in use, no competing references may access the same value. The compiler checks these relationships.</p></div>
      <h2 id="rust-practice">Before reaching for clone</h2>
      <p>Ask whether the function needs to own the value, change it, or merely read it. The answer usually suggests the parameter type.</p>
      <div class="check-list">
        <label class="checklist-row"><input type="checkbox" data-check="rust-move">Trace where a value moves.</label>
        <label class="checklist-row"><input type="checkbox" data-check="rust-borrow">Replace an unnecessary clone with a borrow.</label>
        <label class="checklist-row"><input type="checkbox" data-check="rust-drop">Explain when the value is dropped.</label>
      </div>`
  },
  {
    id: 'project',
    title: 'Programmable Notes',
    icon: 'layers',
    folder: 'Projects',
    tag: 'Product thinking',
    description: 'A document first. A little more powerful when you need it.',
    updated: 'Sample note',
    outline: [
      { id: 'project-idea', title: 'The idea' },
      { id: 'project-principles', title: 'Design principles' },
      { id: 'project-next', title: 'What this prototype explores' }
    ],
    source: '# Programmable Notes\n\nA document first. A little more powerful when you need it.\n\n## The idea\n\nMake room for ordinary writing, mathematical explanations, and small interactive experiments in the same note. React is a capability of the document, not a catalog that determines what the author may create.\n\nThe interface should feel quiet until the work asks for more. Reading should never require understanding the machinery behind the page.\n\n## Design principles\n\n1. Keep the document central.\n2. Let source and visual views complement each other.\n3. Make local ownership understandable.\n4. Keep advanced controls nearby, not permanently in the way.\n\n> A useful interface makes the next action obvious and the rest optional.\n\n## What this prototype explores\n\nThis is a frontend study, not a claim that storage, synchronization, or React compilation is connected. Pages, panels, and settings demonstrate the intended experience.\n\n- [x] A consistent light and dark palette.\n- [x] Navigable sample documents.\n- [ ] Validate the layout with a long real note.\n- [ ] Review the interactions before implementation.\n\nKeep the first useful release focused on writing, reading, and recovering your work.\n',
    body: `
      <h2 id="project-idea">The idea</h2>
      <p>Make room for ordinary writing, mathematical explanations, and small interactive experiments in the same note. React is a capability of the document, not a catalog that determines what the author may create.</p>
      <p>The interface should feel quiet until the work asks for more. Reading should never require understanding the machinery behind the page.</p>
      <h2 id="project-principles">Design principles</h2>
      <ol>
        <li><strong>Keep the document central.</strong> A generous reading column comes before panels.</li>
        <li><strong>Offer two perspectives.</strong> Source and visual views should complement each other.</li>
        <li><strong>Make ownership understandable.</strong> Local files should remain yours.</li>
        <li><strong>Reveal tools in context.</strong> Advanced controls stay nearby, not permanently in the way.</li>
      </ol>
      <blockquote>A useful interface makes the next action obvious and the rest optional.</blockquote>
      <h2 id="project-next">What this prototype explores</h2>
      <p>This is a frontend study, not a claim that storage, synchronization, or React compilation is connected. Pages, panels, and settings demonstrate the intended experience.</p>
      <div class="check-list">
        <label class="checklist-row"><input type="checkbox" data-check="project-palette" checked>A consistent light and dark palette.</label>
        <label class="checklist-row"><input type="checkbox" data-check="project-navigation" checked>Navigable sample documents.</label>
        <label class="checklist-row"><input type="checkbox" data-check="project-long-note">Validate the layout with a long real note.</label>
        <label class="checklist-row"><input type="checkbox" data-check="project-review">Review the interactions before implementation.</label>
      </div>`
  },
  {
    id: 'weekly',
    title: 'Weekly plan',
    icon: 'calendar',
    folder: 'Personal',
    tag: 'A little structure',
    description: 'Choose a few things worth finishing.',
    updated: 'Sample note',
    outline: [
      { id: 'weekly-focus', title: 'This week’s focus' },
      { id: 'weekly-desk', title: 'On the desk' },
      { id: 'weekly-review', title: 'A five-minute review' }
    ],
    source: '# Weekly plan\n\nChoose a few things worth finishing.\n\n## This week’s focus\n\nBuild understanding that lasts longer than the next exercise. Keep one small software milestone moving, and leave enough space to revisit anything that did not click the first time.\n\nThis is a sample planning page. Its tasks are demonstration content, not calendar events or commitments.\n\n## On the desk\n\n- [x] Gather notes in one place.\n- [ ] Explain least squares without looking at the formula.\n- [ ] Write one binary search and test its boundary cases.\n- [ ] Review the new editor on a small screen.\n\nA good stopping point is a clear next action, not an empty task list. Write down where to resume before closing the page.\n\n## A five-minute review\n\nWhat became easier this week?\n\nKeep one concrete example. An explanation that used to need a full page may now fit into three sentences.\n\nWhat deserves another pass?\n\nChoose one difficulty and make the next attempt smaller. A single worked example is often more useful than another broad reading session.\n\nWhat can wait?\n\nMove optional ideas out of the way so they do not compete with the work already chosen.\n',
    body: `
      <h2 id="weekly-focus">This week’s focus</h2>
      <p>Build understanding that lasts longer than the next exercise. Keep one small software milestone moving, and leave enough space to revisit anything that did not click the first time.</p>
      <p class="subtle">This is a sample planning page. Its tasks are demonstration content, not calendar events or commitments.</p>
      <h2 id="weekly-desk">On the desk</h2>
      <div class="check-list">
        <label class="checklist-row"><input type="checkbox" data-check="weekly-gather" checked>Gather notes in one place.</label>
        <label class="checklist-row"><input type="checkbox" data-check="weekly-squares">Explain least squares without looking at the formula.</label>
        <label class="checklist-row"><input type="checkbox" data-check="weekly-search">Write one binary search and test its boundary cases.</label>
        <label class="checklist-row"><input type="checkbox" data-check="weekly-editor">Review the new editor on a small screen.</label>
      </div>
      <div class="note-callout"><span class="callout-label">Leave a thread to pick up</span><p>A good stopping point is a clear next action, not an empty task list. Write down where to resume before closing the page.</p></div>
      <h2 id="weekly-review">A five-minute review</h2>
      <details open><summary>What became easier this week?</summary><p>Keep one concrete example. An explanation that used to need a full page may now fit into three sentences.</p></details>
      <details><summary>What deserves another pass?</summary><p>Choose one difficulty and make the next attempt smaller. A single worked example is often more useful than another broad reading session.</p></details>
      <details><summary>What can wait?</summary><p>Move optional ideas out of the way so they do not compete with the work already chosen.</p></details>`
  },
  {
    id: 'start',
    title: 'A quieter place to think',
    icon: 'leaf',
    folder: 'Personal',
    tag: 'Start here',
    description: 'Notes, ideas, and small experiments. Together.',
    updated: 'Sample note',
    outline: [
      { id: 'start-space', title: 'Make a little space' },
      { id: 'start-explore', title: 'Take a look around' },
      { id: 'start-own', title: 'Make it yours' }
    ],
    source: '# A quieter place to think\n\nNotes, ideas, and small experiments. Together.\n\n## Make a little space\n\nA note does not need to start with a plan. Begin with a question, a fragment of an explanation, or a piece of code you want to understand. Give it a title when the shape becomes clear.\n\nThe workspace is designed to keep the page in view. Navigation stays close, references can sit alongside your writing, and the rest can wait until you need it.\n\n## Take a look around\n\nThe sample pages show a few different rhythms: a mathematical explanation, a programming note, a product idea, and a simple weekly plan.\n\nOpen Algorithms & complexity to see code and a checklist. Open Ownership in Rust for a short technical note, or Weekly plan for collapsible prompts.\n\n## Make it yours\n\nChoose light, dark, or system appearance in Settings. Try the reading preferences and look at the same note again. The best choice is the one that lets the content disappear into the work.\n\nThis is a visual prototype. Sample pages and interface settings live only in the browser when storage is available. Nothing is synchronized to a server.\n',
    body: `
      <h2 id="start-space">Make a little space</h2>
      <p>A note does not need to start with a plan. Begin with a question, a fragment of an explanation, or a piece of code you want to understand. Give it a title when the shape becomes clear.</p>
      <p>The workspace is designed to keep the page in view. Navigation stays close, references can sit alongside your writing, and the rest can wait until you need it.</p>
      <h2 id="start-explore">Take a look around</h2>
      <p>The sample pages show a few different rhythms: a mathematical explanation, a programming note, a product idea, and a simple weekly plan.</p>
      <ul>
        <li><button class="inline-link" data-action="navigate" data-page="algorithms">Algorithms &amp; complexity</button> for code and a checklist.</li>
        <li><button class="inline-link" data-action="navigate" data-page="rust">Ownership in Rust</button> for a short technical note.</li>
        <li><button class="inline-link" data-action="navigate" data-page="weekly">Weekly plan</button> for a little structure.</li>
      </ul>
      <h2 id="start-own">Make it yours</h2>
      <p>Choose light, dark, or system appearance in Settings. Try the reading preferences and look at the same note again. The best choice is the one that lets the content disappear into the work.</p>
      <div class="note-callout"><span class="callout-label">A frontend study</span><p>Sample pages and interface settings live only in the browser when storage is available. Nothing is synchronized to a server.</p></div>`
  }
];
