import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const shell = readFileSync(new URL('./shell.html', import.meta.url), 'utf8');
const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');
const pagesExtra = readFileSync(new URL('./pages-extra.js', import.meta.url), 'utf8');
const styles = readFileSync(new URL('./styles.css', import.meta.url), 'utf8');

test('document canvas exposes exactly two floating panel controls', () => {
  assert.equal((shell.match(/class="floating-toggle/g) || []).length, 2);
  assert.match(shell, /data-action="toggle-sidebar"/);
  assert.match(shell, /data-action="toggle-panel"/);
  assert.doesNotMatch(shell, /class="topbar"|class="editor-toolbar"|class="statusbar"/);
});

test('sidebar contains only search, the folder tree, page creation, and account controls', () => {
  assert.match(shell, /class="search-trigger"/);
  assert.match(shell, /id="page-tree"/);
  assert.match(shell, /class="profile"/);
  assert.doesNotMatch(shell, /All pages|Templates|favorite-button|save-status|status-location|word-count/);
});

test('sample document no longer renders metadata or a bottom utility row', () => {
  assert.doesNotMatch(app, /<div class=\\"doc-meta\\">|<footer class=\\"document-bottom\\">/);
  assert.doesNotMatch(app, /MDX document<\/span>/);
  assert.doesNotMatch(app, /data-action=\\"favorite\\"/);
});

test('code blocks receive a single floating action pill with working controls', () => {
  assert.match(app, /function mountCodeToolbars\(/);
  assert.match(app, /class="code-toolbar"/);
  assert.match(app, /data-action="code-language"/);
  assert.match(app, /data-action="copy-code"/);
  assert.match(app, /data-action="code-wrap"/);
  assert.match(app, /data-action="code-more"/);
  assert.match(app, /mountCodeToolbars\(\);/);
});

test('code pill is invisible at rest and appears on hover or keyboard focus', () => {
  assert.match(styles, /\.code-toolbar\{[^}]*opacity:0;[^}]*visibility:hidden;/);
  assert.match(styles, /\.code-block:hover \.code-toolbar/);
  assert.match(styles, /\.code-block:focus-within \.code-toolbar/);
  assert.match(styles, /\.code-block\[data-tools-open="true"\] \.code-toolbar/);
});

test('centered mode island replaces the editor toolbar and never exposes Split', () => {
  assert.match(shell, /id="mode-island"/);
  assert.match(shell, /data-action="toggle-mode-island"/);
  assert.match(shell, /data-view="visual">Preview/);
  assert.match(shell, /data-view="source">Source/);
  assert.doesNotMatch(shell, /data-view="split"/);
  assert.match(styles, /\.mode-island:hover/);
  assert.doesNotMatch(app.slice(app.indexOf('function renderPanel()'),app.indexOf('function toast(')), /Split|view-tabs/);
});

test('mode island morphs smoothly and slides a single active indicator', () => {
  assert.match(app, /\$\('#mode-island'\)\.dataset\.mode=next/);
  assert.match(styles, /\.mode-island-actions::before\{[^}]*transition:transform 300ms/);
  assert.match(styles, /\.mode-island\[data-mode="source"\] \.mode-island-actions::before\{transform:translateX\(100%\)/);
  assert.match(styles, /\.mode-island:hover,\.mode-island:focus-within,\.mode-island\.is-open\{width:160px;height:32px/);
});

test('floating counts report document or selected text and hide behind details panel', () => {
  assert.match(shell, /id="floating-stats"/);
  assert.match(app, /function updateFloatingStats\(/);
  assert.match(app, /document\.addEventListener\('selectionchange'/);
  assert.match(app, /updateFloatingStats\(\);/);
  assert.match(styles, /\.app-shell\.panel-open \.floating-stats\{[^}]*display:none/);
});

test('document scrolling uses a hairline overlay instead of browser chrome', () => {
  assert.match(shell, /id="scroll-rail"/);
  assert.match(styles, /\.document-scroller,\.source-code\{scrollbar-width:none/);
  assert.match(styles, /\.scroll-thumb\{[^}]*width:3px/);
  assert.match(app, /function updateScrollIndicator\(/);
  assert.match(app, /function revealScrollIndicator\(/);
});

test('mode handle sits nearly flush with the upper edge', () => {
  assert.match(styles, /\.mode-island\{[^}]*top:0;/);
  assert.match(styles, /\.mode-island-handle span\{[^}]*translateY\(-10px\)/);
});

test('code block and contextual pill are vertically compact', () => {
  assert.match(styles, /\.code-block pre\{[^}]*padding:14px 18px;min-height:0;line-height:1\.55/);
  assert.match(styles, /\.code-toolbar button\{height:23px;min-width:23px/);
});

test('disclosures are borderless inline document content', () => {
  assert.match(styles, /\.doc-body details\{border:0;margin:8px 0;padding:0/);
  assert.match(styles, /\.doc-body details>div\{padding:0 0 0 20px/);
  assert.match(styles, /\.doc-body details>div>:first-child\{margin-top:2px/);
});

test('sidebar folders use a folder glyph distinct from the separate chevron', () => {
  assert.match(app, /class="folder-trigger"[^`]+class="folder-chevron"/);
  assert.match(app, /class="folder-mark">\$\{icon\('folder'\)\}/);
  assert.match(app, /querySelector\('\.folder-chevron svg'\)/);
  assert.match(styles, /\.folder-trigger \.folder-mark \.icon\{width:17px;height:17px/);
});

test('callout body text uses the document font and identical size and leading', () => {
  assert.match(styles, /\.note-callout,\.note-callout p\{font-family:inherit;font-size:var\(--body-size\);line-height:var\(--body-leading\)/);
  assert.match(pagesExtra, /The important assumption/);
});

test('JetBrains Mono and XCharter Math styles accompany inline and display math', () => {
  assert.match(styles, /font-family:"JetBrains Mono"/);
  assert.match(styles, /font-family:"XCharter Math"/);
  assert.match(app, /class="inline-math" data-latex=/);
  assert.match(app, /<math display="block"/);
  assert.match(app, /<mfrac>/);
  assert.match(app, /\\\\hat\{\\\\beta\}/);
});

test('display equations use the same font size token as normal paragraphs', () => {
  assert.match(styles, /\.doc-body \.equation\{[^}]*font-size:var\(--body-size\)/);
  assert.match(styles, /\.doc-body \.equation math\{font-size:1em;/);
  assert.doesNotMatch(styles, /\.doc-body \.equation math\{font-size:1\.22em/);
});
