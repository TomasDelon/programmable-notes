#!/bin/bash
set -euo pipefail
exec docker exec -i pn-m3-build ssh -i /infra/guest-key -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/infra/known_hosts -o ConnectTimeout=10 -p 2222 root@127.0.0.1 "$@"
