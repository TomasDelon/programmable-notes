#!/bin/bash
set -euo pipefail
export PATH=/opt/node/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
echo '=== Guest kernel and policy ==='
date -u
uname -a
systemctl --version | head -1
systemd-detect-virt
cat /proc/cmdline
cat /sys/module/apparmor/parameters/enabled
sysctl kernel.unprivileged_userns_clone kernel.apparmor_restrict_unprivileged_userns
aa-status
echo '=== Versions ==='
dpkg-query -W libgtk-3-0t64 libwebkit2gtk-4.1-0 webkit2gtk-driver dbus dbus-user-session libpam-systemd bubblewrap
/opt/node/bin/node --version
/opt/node/bin/npm --version
sha256sum /usr/local/bin/tauri-driver
echo '=== Guest/user controllers and session ==='
systemctl is-system-running || true
systemctl show user@1000.service -p Delegate -p ControlGroup -p ActiveState -p MainPID
cat /sys/fs/cgroup/user.slice/user-1000.slice/user@1000.service/cgroup.controllers
cat /sys/fs/cgroup/user.slice/user-1000.slice/user@1000.service/cgroup.subtree_control
stat -c '%U %a %n' /run/user/1000/pn-Xauthority /run/user/1000/pn-session-ready
findmnt -T /
findmnt -T /work
runuser -u ubuntu -- env XDG_RUNTIME_DIR=/run/user/1000 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus DISPLAY=:99 XAUTHORITY=/run/user/1000/pn-Xauthority PATH=/opt/node/bin:/usr/local/bin:/usr/bin:/bin bash -se <<'USER'
id
systemctl --user is-system-running || true
systemctl --user show-environment
xdpyinfo | sed -n '1,15p'
gdbus call --session --dest org.a11y.Bus --object-path /org/a11y/bus --method org.freedesktop.DBus.Properties.Get org.a11y.Status IsEnabled
gdbus call --session --dest org.a11y.Bus --object-path /org/a11y/bus --method org.freedesktop.DBus.Properties.Get org.a11y.Status ScreenReaderEnabled
python3 -c 'import pyatspi; print("AT-SPI desktop count:", pyatspi.Registry.getDesktopCount())'
USER
