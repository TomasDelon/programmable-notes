"""Trusted infrastructure diagnostic; no author code, files or dialog actions."""
import os
import sys
import gi
gi.require_version('Gtk', '3.0')
gi.require_version('WebKit2', '4.1')
from gi.repository import Gtk, WebKit2, GLib

label = sys.argv[1]
with open(f'/run/user/1000/pn-webkit-sandbox-{label}.pid', 'w') as file:
    file.write(str(os.getpid()))
context = WebKit2.WebContext.new_ephemeral()
print('CONTEXT_DEFAULT_SANDBOX', context.get_sandbox_enabled(), flush=True)
context.set_sandbox_enabled(True)
print('CONTEXT_EXPLICIT_SANDBOX', context.get_sandbox_enabled(), flush=True)
view = WebKit2.WebView.new_with_context(context)
view.connect('load-changed', lambda _, event: print('LOAD_CHANGED', event.value_name, flush=True))
view.connect('web-process-terminated', lambda _, reason: print('WEB_PROCESS_TERMINATED', reason.value_name, flush=True))
window = Gtk.Window(title='Trusted WebKit sandbox diagnostic')
window.set_default_size(500, 200)
window.connect('destroy', lambda *_: Gtk.main_quit())
window.add(view)
window.show_all()
view.load_html('<!doctype html><title>Trusted sandbox probe</title><h1>Trusted sandbox probe</h1>', 'about:blank')
GLib.timeout_add_seconds(20, lambda: (Gtk.main_quit(), False)[1])
Gtk.main()
print('PROBE_EXIT', flush=True)
