#!/bin/bash
# Trusted infrastructure prerequisite only; this does not run application code.
set -u
date -u
sysctl kernel.unprivileged_userns_clone kernel.apparmor_restrict_unprivileged_userns
manager_pid=$(systemctl show user@1000.service -p MainPID --value)
printf 'Root net namespace: '; readlink /proc/self/ns/net
printf 'User manager namespace: '; readlink "/proc/$manager_pid/ns/net"
printf 'User manager profile: '; cat "/proc/$manager_pid/attr/current"
runuser -u ubuntu -- env XDG_RUNTIME_DIR=/run/user/1000 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus systemd-run --user --wait --collect --unit=pn-m3-private-network-probe -p PrivateNetwork=yes -p NoNewPrivileges=yes /usr/bin/true
printf 'TRUE_PROBE_EXIT=%s\n' "$?"
runuser -u ubuntu -- env XDG_RUNTIME_DIR=/run/user/1000 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus systemd-run --user --wait --pipe --collect --unit=pn-m3-network-identity -p PrivateNetwork=yes -p NoNewPrivileges=yes /usr/bin/readlink /proc/self/ns/net
printf 'NETWORK_IDENTITY_EXIT=%s\n' "$?"
journalctl --no-pager --since '-5 minutes' _SYSTEMD_USER_UNIT=pn-m3-private-network-probe.service
journalctl --no-pager --since '-5 minutes' _SYSTEMD_USER_UNIT=pn-m3-network-identity.service
journalctl -k --no-pager --since '-5 minutes' | grep -E 'apparmor|DENIED|audit' || true
cat /etc/apparmor.d/unprivileged_userns
runuser -u ubuntu -- /usr/bin/unshare --user --map-root-user --net /usr/bin/true
printf 'UNSHARE_NET_EXIT=%s\n' "$?"

# A zero systemd-run status alone is insufficient. The recorded Ubuntu build
# warns that PrivateNetwork was skipped and retains the manager network namespace.
