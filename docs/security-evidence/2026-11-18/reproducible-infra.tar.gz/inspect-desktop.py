import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gdk
import pyatspi

desktop = pyatspi.Registry.getDesktop(0)
seen = 0
def walk(node, depth=0):
    global seen
    if seen >= 500 or depth > 9:
        return
    seen += 1
    try:
        name = node.name
        role = node.getRoleName()
        pid = node.get_process_id()
        print('  ' * depth + f'pid={pid} role={role!r} name={name[:400]!r}')
        for index in range(node.childCount):
            walk(node.getChildAtIndex(index), depth+1)
    except Exception as exc:
        print('  ' * depth + f'error={exc!r}')
walk(desktop)
root = Gdk.get_default_root_window()
width, height = root.get_width(), root.get_height()
pixels = Gdk.pixbuf_get_from_window(root, 0, 0, width, height)
pixels.savev('/home/ubuntu/pn-m3-direct-desktop.png', 'png', [], [])
print('SCREENSHOT=/home/ubuntu/pn-m3-direct-desktop.png')
