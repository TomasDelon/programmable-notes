#!/bin/bash
# Execute on the outer workspace after package installation is complete.
set -euo pipefail
umask 022
infra=/tmp/pn-m3-infra
docker exec pn-m3-build bash /infra/configure-guest.sh
docker export -o "$infra/rootfs.tar" pn-m3-build
docker exec -i pn-m3-build bash -se <<'BUILD'
set -euo pipefail
umask 022
mkdir -p /vm/rootfs
tar -C /vm/rootfs -xf /infra/rootfs.tar
printf 'pn-m3-guest\n' > /vm/rootfs/etc/hostname
printf '127.0.0.1 localhost\n127.0.1.1 pn-m3-guest\n' > /vm/rootfs/etc/hosts
rm -f /vm/rootfs/etc/resolv.conf
printf 'nameserver 10.0.2.3\n' > /vm/rootfs/etc/resolv.conf
rm -f /vm/rootfs/.dockerenv /vm/rootfs/etc/machine-id
touch /vm/rootfs/etc/machine-id
cp /boot/vmlinuz-*-generic /vm/vmlinuz
cp /boot/initrd.img-*-generic /vm/initrd.img
truncate -s 24G /vm/guest.ext4
mkfs.ext4 -F -L pn-m3-root -d /vm/rootfs /vm/guest.ext4
e2fsck -fn /vm/guest.ext4
rm -rf /vm/rootfs
BUILD
rm "$infra/rootfs.tar"
