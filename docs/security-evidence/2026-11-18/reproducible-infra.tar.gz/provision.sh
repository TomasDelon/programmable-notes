#!/bin/bash
# Run on the outer workspace. Does not touch a source repository.
set -euo pipefail
umask 022
infra=/tmp/pn-m3-infra
mkdir -p "$infra"
if docker inspect pn-m3-build >/dev/null 2>&1; then
  echo 'Task container pn-m3-build already exists; retain it or explicitly remove it after preserving evidence.' >&2
  exit 1
fi
node_executable=$(command -v node)
node_distribution=$(dirname "$(dirname "$node_executable")")
test "$(node --version)" = v24.22.1
test -d /workspace/.cache/cargo
test -d /workspace/.cache/rustup
cp /etc/ssl/certs/ca-certificates.crt "$infra/host-ca.crt"
mkdir -p "$infra/node" "$infra/cargo" "$infra/rustup"
cp -a "$node_distribution/." "$infra/node/"
cp -a /workspace/.cache/cargo/. "$infra/cargo/"
cp -a /workspace/.cache/rustup/. "$infra/rustup/"
if ! test -e "$infra/guest-key"; then
  ssh-keygen -q -t ed25519 -N '' -f "$infra/guest-key"
fi
docker image inspect ubuntu:24.04 > "$infra/base-image.json"
docker run -d --name pn-m3-build --privileged -v "$infra:/infra" ubuntu:24.04 sleep infinity
docker exec pn-m3-build bash /infra/install-packages.sh > "$infra/install.log" 2>&1
bash "$infra/build-guest-image.sh" > "$infra/image-build.log" 2>&1
docker exec -d pn-m3-build bash -c 'exec bash /infra/start-guest.sh > /infra/guest-console.log 2>&1'
echo 'Guest boot started; run ssh-guest.sh /usr/local/lib/pn-guest-readiness after SSH becomes ready.'
