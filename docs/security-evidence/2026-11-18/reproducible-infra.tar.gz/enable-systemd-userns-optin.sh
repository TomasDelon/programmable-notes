#!/bin/bash
# Explicit administrator integration in this disposable VM only.
# Do not invoke from the generic image recipe or application package hooks.
set -euo pipefail
umask 022
test "$(sysctl -n kernel.apparmor_restrict_unprivileged_userns)" = 1
test -x /usr/lib/systemd/systemd-executor
install -m 644 /work/pn-m3-systemd-executor.apparmor /etc/apparmor.d/pn-m3-systemd-executor
apparmor_parser -r /etc/apparmor.d/pn-m3-systemd-executor
sysctl kernel.unprivileged_userns_clone kernel.apparmor_restrict_unprivileged_userns
sha256sum /etc/apparmor.d/unprivileged_userns /etc/apparmor.d/pn-m3-systemd-executor
