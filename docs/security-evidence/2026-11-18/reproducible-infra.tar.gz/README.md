# Disposable Milestone 3 Linux infrastructure

These scripts configure a disposable Ubuntu 24.04 guest only. Application source,
package metadata and repository files are not changed by infrastructure setup.
No security validation result follows from infrastructure readiness.

Outer prerequisites: rootless Docker, ubuntu:24.04 image, approximately 15 GiB
free disk, 8 GiB guest memory, host trusted certificate bundle, Node 24.22.1,
Rust toolchain/cache, optionally a retained tauri-driver 2.1.0 artifact. If none is
provided, the installer runs `cargo install tauri-driver --version 2.1.0 --locked`.
Keys under this directory are task-local;
do not commit this directory wholesale.

1. Copy the host trust bundle to `host-ca.crt`, Node distribution to `node/`,
   Rustup home to `rustup/`, Cargo home to `cargo/`, and driver to `tauri-driver`.
2. Generate a task-local `ssh-keygen -t ed25519 -N '' -f guest-key`.
3. Start `docker run -d --name pn-m3-build --privileged -v /tmp/pn-m3-infra:/infra ubuntu:24.04 sleep infinity`.
4. Run `docker exec pn-m3-build bash /infra/install-packages.sh`.
5. Run `bash /tmp/pn-m3-infra/build-guest-image.sh`.
6. Run `docker exec -d pn-m3-build bash -c 'exec bash /infra/start-guest.sh > /infra/guest-console.log 2>&1'`.
7. Access with `bash /tmp/pn-m3-infra/ssh-guest.sh COMMAND`.

SSH is bound exclusively to container loopback port 2222. The host key is pinned
from the constructed rootfs before boot. The VM has its own kernel, systemd and
cgroup v2; outer rootless Docker's missing cgroup delegation is not used for tests.
The guest root filesystem is ext4. `/work` shares `/share` in the container through
9p `cache=none` and should hold only static copied dependencies/artifacts; controllers
and application sources should be copied into guest ext4 paths before execution.

The ordinary user is ubuntu, UID 1000. Its persistent manager gets cpu, cpuset, io,
memory and pids delegation. The authenticated Xvfb display is :99; Xauthority is
`/run/user/1000/pn-Xauthority`. The session enables both AT-SPI settings before
application startup and imports the supported WebKit compositing/DMABUF rendering
options into the user manager. No WebKit sandbox switch is configured.

Use `runuser -u ubuntu -- env XDG_RUNTIME_DIR=/run/user/1000 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus DISPLAY=:99 XAUTHORITY=/run/user/1000/pn-Xauthority WEBKIT_DISABLE_COMPOSITING_MODE=1 WEBKIT_DISABLE_DMABUF_RENDERER=1 PATH=/opt/node/bin:/opt/cargo/bin:/usr/local/bin:/usr/bin:/bin COMMAND` inside the guest.

Build container environment: `CARGO_HOME=/opt/cargo RUSTUP_HOME=/opt/rustup PATH=/opt/node/bin:/opt/cargo/bin:/usr/local/bin:/usr/bin:/bin`.

The initial infrastructure check retains Ubuntu's hardened
`kernel.apparmor_restrict_unprivileged_userns=1`. `hardened-prerequisite.sh`
records the actual systemd/userns behavior. On this image, `systemd-run` of true
with `PrivateNetwork=yes` returns zero while warning that isolation was skipped.
A trusted readlink service proves its network namespace equals the user manager's;
kernel audit attributes the failure to the `unprivileged_userns` AppArmor profile
denying `sys_admin`. This is a prerequisite blocker, not a containment pass. Do not
relax AppArmor or infer that an application works from this infrastructure result.

An optional **explicit administrator** integration is retained separately as
`pn-m3-systemd-executor.apparmor` and `enable-systemd-userns-optin.sh`. The generic
image and application install do not apply it. After capturing the strict baseline,
copy these two files to the container `/share`, then run the enable script inside
the guest as root. It attaches an Ubuntu-style named unconfined profile with a
`userns` opt-in to `/usr/lib/systemd/systemd-executor`. A trusted service then has a
different actual network namespace and NoNewPrivs=1 while direct unprofiled
UID1000 `unshare` remains denied. Service descendants inherit this named profile;
this expands the administrator's namespace trust to systemd-launched services.
Both recorded settings (`kernel.unprivileged_userns_clone=1` and
`kernel.apparmor_restrict_unprivileged_userns=1`) remain unchanged and the distribution's `unprivileged_userns`
profile stays byte-identical. Strict baseline and opt-in evidence are separate.

`webkit-sandbox-view.py` is a trusted minimal WebKit/GTK diagnostic that loads
only fixed HTML and exits after 20 seconds. On WebKitGTK 2.52.6, default and
ephemeral context sandbox flags both default to false; setting the flag true is
supported. A direct unprofiled launch then fails at bwrap's uid map under the strict
policy. The identical diagnostic run as a user service under the explicit executor
opt-in loads successfully; its WebProcess has NoNewPrivs=1, Seccomp=2/filter count=1,
and distinct mount/network/PID/user/UTS namespaces. The WebKit NetworkProcess is
outside that engine sandbox. This diagnostic does not establish any application's
context settings; actual application process metadata must be checked independently.

The recipe installs acl (`getfacl`/`setfacl`), GTK3 introspection, and both the desktop
portal and GTK file-chooser backend. A generic portal configuration selects the
GTK backend for the Openbox session. Browser/app download correctness still needs
the actual packaged application and real file-dialog tests.

Before any offline rootfs modification, shut the guest down and confirm QEMU has
exited. Never mount or modify a live image. Preserve evidence before deleting
only the task-owned `pn-m3-build` container and this task's temporary artifacts.
