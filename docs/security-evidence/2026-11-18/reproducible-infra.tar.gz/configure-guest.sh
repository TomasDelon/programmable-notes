#!/bin/bash
set -euo pipefail
umask 022
getent passwd ubuntu
mkdir -p /root/.ssh /etc/systemd/system/user@.service.d /etc/systemd/network /var/lib/systemd/linger /usr/local/lib /work /opt/pn
chmod 700 /root/.ssh
chmod 755 /etc/systemd/system/user@.service.d /etc/systemd/network /var/lib/systemd/linger /opt/pn
install -m 600 /infra/guest-key.pub /root/.ssh/authorized_keys
cp /infra/guest-session.sh /usr/local/lib/pn-guest-session
cp /infra/guest-readiness.sh /usr/local/lib/pn-guest-readiness
chmod 755 /usr/local/lib/pn-guest-session
chmod 755 /usr/local/lib/pn-guest-readiness
printf '[Service]\nDelegate=cpu cpuset io memory pids\n' > /etc/systemd/system/user@.service.d/delegate.conf
printf 'kernel.apparmor_restrict_unprivileged_userns=1\n' > /etc/sysctl.d/60-pn-hardening.conf
touch /var/lib/systemd/linger/ubuntu
printf '/dev/vda / ext4 defaults 0 1\nwork /work 9p trans=virtio,version=9p2000.L,cache=none,_netdev 0 0\n' > /etc/fstab
printf '[Match]\nName=en* eth*\n[Network]\nDHCP=yes\n' > /etc/systemd/network/20-wired.network
mkdir -p /etc/ssh/sshd_config.d
mkdir -p /etc/xdg/xdg-desktop-portal
printf '[preferred]\ndefault=gtk\norg.freedesktop.impl.portal.FileChooser=gtk\n' > /etc/xdg/xdg-desktop-portal/portals.conf
printf 'PermitRootLogin prohibit-password\nPasswordAuthentication no\nKbdInteractiveAuthentication no\nUsePAM yes\n' > /etc/ssh/sshd_config.d/pn.conf
cat > /etc/systemd/system/pn-graphical-session.service <<'UNIT'
[Unit]
Description=Private authenticated native validation Xvfb session
Requires=user@1000.service
After=user@1000.service systemd-user-sessions.service
[Service]
Type=simple
User=ubuntu
Group=ubuntu
ExecStart=/usr/local/lib/pn-guest-session
Restart=on-failure
[Install]
WantedBy=multi-user.target
UNIT
systemctl enable systemd-networkd ssh pn-graphical-session
chmod 644 /etc/systemd/system/pn-graphical-session.service /etc/systemd/system/user@.service.d/delegate.conf /etc/sysctl.d/60-pn-hardening.conf /etc/systemd/network/20-wired.network /etc/ssh/sshd_config.d/pn.conf
ssh-keygen -A
printf '[127.0.0.1]:2222 ' > /infra/known_hosts
cat /etc/ssh/ssh_host_ed25519_key.pub >> /infra/known_hosts
chown -R 1000:1000 /opt/cargo /opt/rustup /opt/pn
