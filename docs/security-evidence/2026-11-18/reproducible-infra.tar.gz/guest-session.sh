#!/bin/bash
set -euo pipefail
export DISPLAY=:99 XDG_RUNTIME_DIR=/run/user/1000 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus
export XDG_SESSION_TYPE=x11 XDG_CURRENT_DESKTOP=Openbox DESKTOP_SESSION=openbox
export XAUTHORITY=$XDG_RUNTIME_DIR/pn-Xauthority
export WEBKIT_DISABLE_COMPOSITING_MODE=1 WEBKIT_DISABLE_DMABUF_RENDERER=1
umask 077
touch "$XAUTHORITY"
xauth -f "$XAUTHORITY" add "$DISPLAY" . "$(mcookie)"
Xvfb "$DISPLAY" -screen 0 1280x900x24 -nolisten tcp -auth "$XAUTHORITY" &
xpid=$!
trap 'kill "$xpid" 2>/dev/null || true' EXIT
for attempt in {1..120}; do
  if xdpyinfo >/dev/null 2>&1; then break; fi
  sleep 1
done
xdpyinfo >/dev/null
openbox --sm-disable > "$XDG_RUNTIME_DIR/pn-openbox.log" 2>&1 &
systemctl --user set-environment DISPLAY="$DISPLAY" XAUTHORITY="$XAUTHORITY" XDG_SESSION_TYPE=x11 XDG_CURRENT_DESKTOP=Openbox DESKTOP_SESSION=openbox WEBKIT_DISABLE_COMPOSITING_MODE=1 WEBKIT_DISABLE_DMABUF_RENDERER=1
gdbus call --session --dest org.a11y.Bus --object-path /org/a11y/bus --method org.freedesktop.DBus.Properties.Set org.a11y.Status IsEnabled '<true>'
gdbus call --session --dest org.a11y.Bus --object-path /org/a11y/bus --method org.freedesktop.DBus.Properties.Set org.a11y.Status ScreenReaderEnabled '<true>'
touch "$XDG_RUNTIME_DIR/pn-session-ready"
wait "$xpid"
