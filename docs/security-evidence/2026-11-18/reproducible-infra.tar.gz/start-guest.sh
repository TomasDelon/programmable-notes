#!/bin/bash
set -euo pipefail
exec qemu-system-x86_64 \
  -machine accel=tcg -cpu max -smp 4 -m 8192 \
  -kernel /vm/vmlinuz -initrd /vm/initrd.img \
  -append 'root=/dev/vda rw console=ttyS0 systemd.unified_cgroup_hierarchy=1 apparmor=1 security=apparmor' \
  -drive file=/vm/guest.ext4,format=raw,if=virtio,cache=writeback \
  -netdev user,id=net0,hostfwd=tcp:127.0.0.1:2222-:22 \
  -device virtio-net-pci,netdev=net0 \
  -virtfs local,path=/share,mount_tag=work,security_model=none,id=work \
  -nographic -monitor unix:/vm/monitor.sock,server=on,wait=off \
  -pidfile /vm/qemu.pid -no-reboot
