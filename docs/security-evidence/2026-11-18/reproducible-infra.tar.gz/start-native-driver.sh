#!/bin/bash
# Run as UID1000 in the guest, after explicit admin opt-in if required.
# Starts only WebDriver infrastructure; it does not start an application.
set -euo pipefail
export XDG_RUNTIME_DIR=/run/user/1000
export DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus
test "$(id -u)" = 1000
test -f "$XDG_RUNTIME_DIR/pn-session-ready"
systemd-run --user --collect --unit=pn-m3-native-driver \
  --setenv=DISPLAY=:99 \
  --setenv=XAUTHORITY=/run/user/1000/pn-Xauthority \
  --setenv=WEBKIT_DISABLE_COMPOSITING_MODE=1 \
  --setenv=WEBKIT_DISABLE_DMABUF_RENDERER=1 \
  /usr/local/bin/tauri-driver --port 4444
