#!/bin/bash
set -euo pipefail
umask 022
export DEBIAN_FRONTEND=noninteractive
mkdir -p /etc/ssl/certs
cp /infra/host-ca.crt /etc/ssl/certs/ca-certificates.crt
apt-get update
apt-get install -y --no-install-recommends ca-certificates curl openssh-client openssh-server rsync sudo systemd systemd-sysv dbus dbus-system-bus-common dbus-user-session dbus-x11 libpam-systemd linux-image-generic initramfs-tools qemu-system-x86 qemu-utils e2fsprogs iproute2 iputils-ping apparmor apparmor-utils build-essential pkg-config libwebkit2gtk-4.1-dev libgtk-3-dev libxdo-dev libssl-dev librsvg2-dev libayatana-appindicator3-dev patchelf webkit2gtk-driver xvfb xauth xdotool python3-pyatspi at-spi2-core dconf-cli fonts-dejavu-core x11-utils x11-xserver-utils file python3 unzip
cp /infra/host-ca.crt /etc/ssl/certs/ca-certificates.crt
mkdir -p /opt/node /opt/rustup /opt/cargo /build /vm /share
apt-get install -y --no-install-recommends openbox xdg-utils procps lsof acl xdg-desktop-portal xdg-desktop-portal-gtk python3-gi ripgrep
cp -a /infra/node/. /opt/node/
chown -R root:root /opt/node
chmod 755 /opt/node
cp -a /infra/rustup/. /opt/rustup/
cp -a /infra/cargo/. /opt/cargo/
if test -f /infra/tauri-driver; then
  cp /infra/tauri-driver /usr/local/bin/tauri-driver
else
  env CARGO_HOME=/opt/cargo RUSTUP_HOME=/opt/rustup PATH=/opt/cargo/bin:/usr/bin:/bin cargo install tauri-driver --version 2.1.0 --locked --root /opt/pn-driver
  cp /opt/pn-driver/bin/tauri-driver /usr/local/bin/tauri-driver
fi
chmod 755 /usr/local/bin/tauri-driver
echo 'export CARGO_HOME=/opt/cargo RUSTUP_HOME=/opt/rustup PATH=/opt/node/bin:/opt/cargo/bin:$PATH' > /etc/profile.d/pn-toolchain.sh
test -e /var/lib/dpkg/status
dpkg-query -W > /infra/packages.log
