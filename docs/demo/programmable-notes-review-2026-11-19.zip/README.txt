Programmable Notes review demo (not a public release).

Open walkthrough/walkthrough.html for the recording, screenshots and actual saved MDX.
To run the browser editor, open a terminal in browser-build and run:
  python3 -m http.server 8000 --bind 127.0.0.1
Then open http://127.0.0.1:8000 in Chromium. No Node/npm install is needed.

This is a local browser demo. Native filesystem permissions, WebKitGTK, cgroups,
and Linux recovery require separate native tests. Browser CPU/memory quotas are
not claimed. No production security readiness or public release is implied.
